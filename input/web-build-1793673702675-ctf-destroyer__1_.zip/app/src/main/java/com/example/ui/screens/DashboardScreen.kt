package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AttachedFile
import com.example.model.Screen
import com.example.ui.components.ChallengeInputBar
import com.example.ui.components.CyberFilePicker
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*

data class ModuleCardInfo(
  val screen: Screen,
  val title: String,
  val code: String,
  val icon: ImageVector,
  val description: String,
  val toolInspiration: String,
  val accentColor: Color,
  val testTag: String
)

@Composable
fun DashboardScreen(
  operatorName: String,
  currentFile: AttachedFile?,
  onFileSelected: (AttachedFile) -> Unit,
  challengeDesc: String,
  onChallengeDescChange: (String) -> Unit,
  onNavigateToScreen: (Screen) -> Unit,
  onRunAiSolver: () -> Unit,
  onLogout: () -> Unit
) {
  val modules = remember {
    listOf(
      ModuleCardInfo(
        screen = Screen.FORENSICS,
        title = "Forensics",
        code = "MOD-01",
        icon = Icons.Default.Search,
        description = "Disk triage, unallocated cluster file carving, registry inspection & metadata recovery.",
        toolInspiration = "INSPIRED BY AUTOPSY",
        accentColor = CyberRed,
        testTag = "nav_forensics"
      ),
      ModuleCardInfo(
        screen = Screen.NETWORKING,
        title = "Networking",
        code = "MOD-02",
        icon = Icons.Default.Lan,
        description = "Deep packet dissection, display filter engine, TCP stream reassembly & flag exfiltration extraction.",
        toolInspiration = "INSPIRED BY WIRESHARK",
        accentColor = CyberCyan,
        testTag = "nav_networking"
      ),
      ModuleCardInfo(
        screen = Screen.CRYPTOGRAPHY,
        title = "Cryptography",
        code = "MOD-03",
        icon = Icons.Default.Lock,
        description = "Multi-cipher cracker: Base64, ROT13/Caesar brute force, XOR keys, Vigenère & hash identifiers.",
        toolInspiration = "CYBERCHEF SUITE",
        accentColor = CyberYellow,
        testTag = "nav_cryptography"
      ),
      ModuleCardInfo(
        screen = Screen.REVERSE_ENGINEERING,
        title = "Reverse Engineering",
        code = "MOD-04",
        icon = Icons.Default.BugReport,
        description = "ELF/PE x86-64 disassembler, decompiled C pseudocode analysis & interactive keygen crackme sandbox.",
        toolInspiration = "INSPIRED BY GHIDRA",
        accentColor = CyberRedLight,
        testTag = "nav_reverse_engineering"
      ),
      ModuleCardInfo(
        screen = Screen.WEB_SECURITY,
        title = "Web Security",
        code = "MOD-05",
        icon = Icons.Default.Language,
        description = "HTTP request repeater, SQL injection sandbox, XSS payload testing, command injection & JWT tampering.",
        toolInspiration = "BURP REPEATER LAB",
        accentColor = CyberOrange,
        testTag = "nav_web_security"
      ),
      ModuleCardInfo(
        screen = Screen.STEGANOGRAPHY,
        title = "Steganography",
        code = "MOD-06",
        icon = Icons.Default.Visibility,
        description = "Sub-pixel LSB bit plane extractor (RGBA), EXIF geospatial metadata & EOF payload carver.",
        toolInspiration = "ZSTEG & STEGSOVLE",
        accentColor = CyberGreen,
        testTag = "nav_steganography"
      ),
      ModuleCardInfo(
        screen = Screen.OSINT,
        title = "OSINT",
        code = "MOD-07",
        icon = Icons.Default.Radar,
        description = "Digital footprint reconnaissance, cross-platform username correlation, IP intel & metadata dossiers.",
        toolInspiration = "SHERLOCK & RECON-NG",
        accentColor = CyberCyan,
        testTag = "nav_osint"
      ),
      ModuleCardInfo(
        screen = Screen.AI_SOLVER,
        title = "AI Auto Solver",
        code = "MOD-08",
        icon = Icons.Default.SmartToy,
        description = "Automated neural heuristic solver: magic bytes, regex flag hunt, multi-stage cipher solver & PoC generator.",
        toolInspiration = "NEURAL HEURISTIC ENGINE",
        accentColor = CyberGreenBright,
        testTag = "nav_ai_solver"
      )
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("dashboard_screen")
  ) {
    // Top Bar
    CyberHeader(
      title = "CTF DESTROYER // COMMAND CENTER",
      categoryBadge = "OPERATOR: $operatorName",
      onBackClick = null,
      actions = {
        IconButton(
          onClick = onLogout,
          modifier = Modifier
            .size(36.dp)
            .testTag("dashboard_logout_button")
        ) {
          Icon(
            imageVector = Icons.Default.ExitToApp,
            contentDescription = "Logout",
            tint = CyberRedLight
          )
        }
      }
    )

    // Main scrollable area
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 14.dp, vertical = 8.dp)
        .verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // 1. File Picker Interface
      CyberFilePicker(
        currentFile = currentFile,
        onFileSelected = onFileSelected
      )

      // 2. Challenge Description Input & Manual / AI Analysis buttons
      ChallengeInputBar(
        description = challengeDesc,
        onDescriptionChange = onChallengeDescChange,
        onManualAnalysisClick = {
          // Open relevant module based on loaded file or default to Networking/Forensics
          val target = when {
            currentFile?.name?.endsWith(".pcap") == true -> Screen.NETWORKING
            currentFile?.name?.endsWith(".dd") == true -> Screen.FORENSICS
            currentFile?.name?.endsWith(".elf") == true -> Screen.REVERSE_ENGINEERING
            currentFile?.name?.endsWith(".enc") == true -> Screen.CRYPTOGRAPHY
            currentFile?.name?.endsWith(".png") == true -> Screen.STEGANOGRAPHY
            currentFile?.name?.endsWith(".php") == true -> Screen.WEB_SECURITY
            else -> Screen.NETWORKING
          }
          onNavigateToScreen(target)
        },
        onAiAnalysisClick = onRunAiSolver
      )

      // Section Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Apps,
            contentDescription = null,
            tint = CyberRed,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "TACTICAL CYBERSECURITY MODULES (8/8 ARMED)",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            ),
            color = CyberTextPrimary
          )
        }

        Text(
          text = "SELECT ANY SECTOR TO LAUNCH DEDICATED WORKSTATION",
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
          color = CyberGreen
        )
      }

      // 3. Responsive Module Grid (2 rows x 4 columns)
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Row 1: Forensics, Networking, Cryptography, Reverse Engineering
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          modules.take(4).forEach { module ->
            ModuleCard(
              module = module,
              modifier = Modifier.weight(1f),
              onClick = { onNavigateToScreen(module.screen) }
            )
          }
        }

        // Row 2: Web Security, Steganography, OSINT, AI Auto Solver
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          modules.drop(4).forEach { module ->
            ModuleCard(
              module = module,
              modifier = Modifier.weight(1f),
              onClick = { onNavigateToScreen(module.screen) }
            )
          }
        }
      }

      // Bottom Telemetry Live Ticker
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 4.dp, bottom = 4.dp),
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(CyberGreen)
            )
            Text(
              text = "SYS_KERNEL: CTF_DESTROYER_V3.2_OK // BUFFER_HEALTH: 100% // ENCRYPTION: AES-256-GCM",
              style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
              ),
              color = CyberTextSecondary
            )
          }

          Text(
            text = "LANDSCAPE COCKPIT ACTIVE",
            style = MaterialTheme.typography.bodySmall.copy(
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp
            ),
            color = CyberGreenBright
          )
        }
      }
    }
  }
}

@Composable
private fun ModuleCard(
  module: ModuleCardInfo,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .height(138.dp)
      .clickable(onClick = onClick)
      .testTag(module.testTag),
    colors = CardDefaults.cardColors(containerColor = CyberSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
    shape = RoundedCornerShape(8.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(10.dp),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          modifier = Modifier.size(32.dp),
          shape = RoundedCornerShape(6.dp),
          color = module.accentColor.copy(alpha = 0.15f),
          border = androidx.compose.foundation.BorderStroke(1.dp, module.accentColor)
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = module.icon,
              contentDescription = null,
              tint = module.accentColor,
              modifier = Modifier.size(18.dp)
            )
          }
        }

        Surface(
          color = CyberSurfaceVariant,
          shape = RoundedCornerShape(4.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
        ) {
          Text(
            text = module.code,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = CyberTextMuted
          )
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
          text = module.title,
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = CyberTextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = module.description,
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, lineHeight = 13.sp),
          color = CyberTextSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = module.toolInspiration,
          style = MaterialTheme.typography.labelSmall.copy(
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold
          ),
          color = module.accentColor
        )

        Icon(
          imageVector = Icons.Default.ChevronRight,
          contentDescription = null,
          tint = CyberRed,
          modifier = Modifier.size(14.dp)
        )
      }
    }
  }
}
