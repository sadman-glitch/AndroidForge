package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*

data class OsintFootprint(
  val platform: String,
  val url: String,
  val status: String,
  val finding: String,
  val isAlert: Boolean = false
)

@Composable
fun OsintScreen(
  onNavigateBack: () -> Unit
) {
  var targetUsername by remember { mutableStateOf("cyber_phantom_99") }
  var isScanning by remember { mutableStateOf(false) }
  var isReportCompiled by remember { mutableStateOf(true) }
  val clipboard = LocalClipboardManager.current

  val footprints = remember {
    listOf(
      OsintFootprint("GitHub", "github.com/cyber_phantom_99", "FOUND", "Commit history contains leaked repo: leak/flag.txt", isAlert = true),
      OsintFootprint("HackTheBox", "app.hackthebox.com/profile/cyber_phantom_99", "FOUND", "Pro Hacker rank, last active 2 hours ago"),
      OsintFootprint("Keybase", "keybase.io/cyber_phantom_99", "FOUND", "Verified GPG Key: 4A8B 9C0D 1E2F 3A4B"),
      OsintFootprint("Pastebin", "pastebin.com/u/cyber_phantom_99", "FOUND", "Public paste with auth endpoint reference", isAlert = true),
      OsintFootprint("TryHackMe", "tryhackme.com/p/cyber_phantom_99", "FOUND", "Top 1% badge in Security Operations"),
      OsintFootprint("X / Twitter", "twitter.com/cyber_phantom_99", "NOT FOUND", "Account not registered or private")
    )
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("osint_screen")
  ) {
    CyberHeader(
      title = "CYBER RECONNAISSANCE // TARGET: CYBER_PHANTOM_99",
      categoryBadge = "OSINT",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            isScanning = true
            isReportCompiled = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("compile_osint_dossier_button")
        ) {
          Text("COMPILE DOSSIER", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag banner
    Surface(
      modifier = Modifier.fillMaxWidth().testTag("osint_flag_banner"),
      color = CyberRedDark.copy(alpha = 0.4f),
      border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Radar, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
          Text(
            text = "FLAG IDENTIFIED IN GITHUB COMMIT: flag{0s1nt_r3c0n_f00tpr1nt_d0ss13r}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberCyan
          )
        }
        Button(
          onClick = { clipboard.setText(AnnotatedString("flag{0s1nt_r3c0n_f00tpr1nt_d0ss13r}")) },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
          modifier = Modifier.height(26.dp)
        ) {
          Text("COPY FLAG", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: Username Scanner & Platform Results
      Card(
        modifier = Modifier
          .weight(1.1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "SHERLOCK DIGITAL FOOTPRINT SCANNER",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberCyan
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            OutlinedTextField(
              value = targetUsername,
              onValueChange = { targetUsername = it },
              modifier = Modifier.weight(1f).height(46.dp).testTag("osint_target_input"),
              singleLine = true,
              textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberYellow)
            )

            Button(
              onClick = { isReportCompiled = true },
              colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.height(46.dp)
            ) {
              Text("SCAN", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
            }
          }

          footprints.forEach { fp ->
            Surface(
              modifier = Modifier.fillMaxWidth(),
              color = if (fp.isAlert) CyberRedDim else CyberSurfaceVariant,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (fp.isAlert) CyberRed else CyberBorder),
              shape = RoundedCornerShape(4.dp)
            ) {
              Column(modifier = Modifier.padding(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = fp.platform,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                  )
                  Surface(
                    color = if (fp.status == "FOUND") CyberGreenDark else CyberSurface,
                    shape = RoundedCornerShape(3.dp)
                  ) {
                    Text(
                      text = fp.status,
                      modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                      color = if (fp.status == "FOUND") CyberGreenBright else CyberTextMuted
                    )
                  }
                }
                Text(
                  text = fp.url,
                  style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                  color = CyberCyan
                )
                Text(
                  text = fp.finding,
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                  color = if (fp.isAlert) CyberRedLight else CyberTextSecondary
                )
              }
            }
          }
        }
      }

      // Right Column: Geospatial Intel & Target Dossier Summary
      Card(
        modifier = Modifier
          .weight(0.9f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberBlack),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "TARGET DOSSIER & GEO COORDINATES",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberYellow
          )

          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberSurface,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
          ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("PRIMARY ALIAS: cyber_phantom_99", style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
              Text("EMAIL FORMAT: phantom.sec@protonmail.internal", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = CyberTextSecondary)
              Text("EXIF GPS: 37° 46' 29.99\" N, 122° 25' 9.84\" W", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = CyberGreenBright)
              Text("ESTIMATED LOCATION: San Francisco, CA, USA", style = MaterialTheme.typography.bodySmall, color = CyberYellow)
              Text("TIMEZONE: UTC-7 (PDT)", style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary)
            }
          }

          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberRedDark.copy(alpha = 0.2f),
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed)
          ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text("CORRELATED EVIDENCE:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberRedLight)
              Text("1. Commit history on GitHub leaked internal API endpoint /api/submit_flag", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
              Text("2. Exfiltration packet capture in Wireshark matched target IP 192.168.1.45", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
              Text("3. Flag recovered from git diff: flag{0s1nt_r3c0n_f00tpr1nt_d0ss13r}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold), color = CyberRedLight)
            }
          }
        }
      }
    }
  }
}
