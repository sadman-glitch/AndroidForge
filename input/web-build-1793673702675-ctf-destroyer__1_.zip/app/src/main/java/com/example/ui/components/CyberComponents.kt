package com.example.ui.components

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.model.AttachedFile
import com.example.ui.theme.*
import java.io.InputStream
import java.security.MessageDigest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberHeader(
  title: String,
  categoryBadge: String,
  onBackClick: (() -> Unit)? = null,
  actions: @Composable RowScope.() -> Unit = {}
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .height(52.dp)
      .testTag("cyber_header"),
    color = CyberBlack,
    tonalElevation = 6.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        if (onBackClick != null) {
          IconButton(
            onClick = onBackClick,
            modifier = Modifier
              .size(38.dp)
              .testTag("nav_back_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Navigate Back",
              tint = CyberRedLight
            )
          }
        }

        Icon(
          imageVector = Icons.Default.Security,
          contentDescription = "Cyber Security",
          tint = CyberRed,
          modifier = Modifier.size(22.dp)
        )

        Text(
          text = title.uppercase(),
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          ),
          color = CyberTextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )

        Surface(
          color = CyberRedDark.copy(alpha = 0.4f),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed),
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = categoryBadge,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberRedLight
          )
        }
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Telemetry status
        Surface(
          color = CyberGreenDim,
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderGreen),
          shape = RoundedCornerShape(4.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(CyberGreen)
            )
            Text(
              text = "NET: ARMED",
              style = MaterialTheme.typography.labelSmall,
              color = CyberGreenBright
            )
          }
        }

        // Clearance badge
        Surface(
          color = CyberSurfaceVariant,
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(
            text = "OP: ROOT [TIER-1]",
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelSmall,
            color = CyberCyan
          )
        }

        actions()
      }
    }
  }
}

@Composable
fun CyberFilePicker(
  currentFile: AttachedFile?,
  onFileSelected: (AttachedFile) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var showPresetDialog by remember { mutableStateOf(false) }

  // SAF Document picker launcher
  val fileLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    uri?.let { selectedUri ->
      val fileDetails = extractFileDetails(context, selectedUri)
      onFileSelected(fileDetails)
    }
  }

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("cyber_file_picker_card"),
    colors = CardDefaults.cardColors(containerColor = CyberSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
    shape = RoundedCornerShape(8.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Surface(
          modifier = Modifier.size(40.dp),
          color = if (currentFile != null) CyberRedDim else CyberSurfaceVariant,
          shape = RoundedCornerShape(6.dp),
          border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (currentFile != null) CyberRed else CyberBorder
          )
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (currentFile != null) Icons.Default.InsertDriveFile else Icons.Default.FileUpload,
              contentDescription = "File Status",
              tint = if (currentFile != null) CyberRedLight else CyberTextSecondary,
              modifier = Modifier.size(22.dp)
            )
          }
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = currentFile?.name ?: "No target artifact loaded",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = if (currentFile != null) CyberGreenBright else CyberTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = if (currentFile != null) {
              "${currentFile.sizeBytes / 1024} KB • MD5: ${currentFile.md5.take(12)}... • ${currentFile.mimeType}"
            } else {
              "Load a .pcap, .dd, .enc, .elf, or .png binary for forensic analysis"
            },
            style = MaterialTheme.typography.bodySmall,
            color = CyberTextMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
      }

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = { showPresetDialog = true },
          modifier = Modifier
            .height(38.dp)
            .testTag("sample_artifacts_button"),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderGreen),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 10.dp)
        ) {
          Icon(
            imageVector = Icons.Default.FolderSpecial,
            contentDescription = null,
            tint = CyberGreen,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            "PRESET ARTIFACTS",
            style = MaterialTheme.typography.labelSmall,
            color = CyberGreen
          )
        }

        Button(
          onClick = { fileLauncher.launch("*/*") },
          modifier = Modifier
            .height(38.dp)
            .testTag("browse_device_files_button"),
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.UploadFile,
            contentDescription = null,
            tint = CyberBlack,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            "BROWSE STORAGE",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberBlack
          )
        }
      }
    }
  }

  if (showPresetDialog) {
    AlertDialog(
      onDismissRequest = { showPresetDialog = false },
      title = {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Icon(Icons.Default.Storage, contentDescription = null, tint = CyberRed)
          Text(
            "CTF TARGET EVIDENCE REPOSITORY",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = CyberTextPrimary
          )
        }
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 280.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          CtfRepository.sampleFiles.forEach { file ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  onFileSelected(file)
                  showPresetDialog = false
                },
              color = if (currentFile?.name == file.name) CyberRedDim else CyberSurfaceVariant,
              border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (currentFile?.name == file.name) CyberRed else CyberBorder
              ),
              shape = RoundedCornerShape(6.dp)
            ) {
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = file.name,
                    style = MaterialTheme.typography.labelLarge,
                    color = CyberTextPrimary
                  )
                  Text(
                    text = "${file.mimeType} • ${file.sizeBytes / 1024} KB",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                  )
                  Text(
                    text = file.previewText,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                  )
                }
                Icon(
                  imageVector = Icons.Default.CheckCircle,
                  contentDescription = null,
                  tint = if (currentFile?.name == file.name) CyberGreen else Color.Transparent
                )
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showPresetDialog = false }) {
          Text("CLOSE", color = CyberTextSecondary)
        }
      },
      containerColor = CyberSurface,
      shape = RoundedCornerShape(8.dp)
    )
  }
}

@Composable
fun ChallengeInputBar(
  description: String,
  onDescriptionChange: (String) -> Unit,
  onManualAnalysisClick: () -> Unit,
  onAiAnalysisClick: () -> Unit,
  modifier: Modifier = Modifier,
  isAnalyzing: Boolean = false
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("challenge_input_card"),
    colors = CardDefaults.cardColors(containerColor = CyberSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
    shape = RoundedCornerShape(8.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Terminal,
            contentDescription = null,
            tint = CyberGreen,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = "CHALLENGE OBJECTIVE / DISSECTION QUERY",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberTextSecondary
          )
        }

        // Quick template buttons
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          TemplateChip(text = "HTTP Exfiltration") {
            onDescriptionChange("Examine intercepted HTTP POST request for exfiltrated credentials and flag format flag{...}")
          }
          TemplateChip(text = "Deleted PNG Carving") {
            onDescriptionChange("Carve deleted image header from unallocated cluster 4192 and extract embedded comments.")
          }
          TemplateChip(text = "Binary Key Bypass") {
            onDescriptionChange("Reverse engineer validate_key() subroutine in ELF binary and recover license flag.")
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        OutlinedTextField(
          value = description,
          onValueChange = onDescriptionChange,
          modifier = Modifier
            .weight(1f)
            .height(52.dp)
            .testTag("challenge_description_input"),
          placeholder = {
            Text(
              "Enter challenge details, clues, regex flag format (e.g. flag{...}), or attack hypothesis...",
              style = MaterialTheme.typography.bodySmall,
              color = CyberTextMuted
            )
          },
          textStyle = MaterialTheme.typography.bodySmall.copy(
            color = CyberTextPrimary,
            fontFamily = FontFamily.Monospace
          ),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = CyberRed,
            unfocusedBorderColor = CyberBorder,
            focusedContainerColor = CyberBlack,
            unfocusedContainerColor = CyberBlack
          ),
          singleLine = true,
          shape = RoundedCornerShape(6.dp)
        )

        // Manual Analysis button
        OutlinedButton(
          onClick = onManualAnalysisClick,
          modifier = Modifier
            .height(48.dp)
            .testTag("manual_analysis_button"),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed),
          colors = ButtonDefaults.outlinedButtonColors(
            containerColor = CyberRedDark.copy(alpha = 0.2f)
          ),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 14.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Build,
            contentDescription = null,
            tint = CyberRedLight,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            "MANUAL ANALYSIS",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberRedLight
          )
        }

        // AI Auto Solver button
        Button(
          onClick = onAiAnalysisClick,
          modifier = Modifier
            .height(48.dp)
            .testTag("ai_analysis_button"),
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(6.dp),
          contentPadding = PaddingValues(horizontal = 16.dp),
          enabled = !isAnalyzing
        ) {
          if (isAnalyzing) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              color = CyberBlack,
              strokeWidth = 2.dp
            )
          } else {
            Icon(
              imageVector = Icons.Default.SmartToy,
              contentDescription = null,
              tint = CyberBlack,
              modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            if (isAnalyzing) "SOLVING..." else "AI ANALYSIS",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
            color = CyberBlack
          )
        }
      }
    }
  }
}

@Composable
private fun TemplateChip(text: String, onClick: () -> Unit) {
  Surface(
    modifier = Modifier.clickable(onClick = onClick),
    color = CyberSurfaceVariant,
    shape = RoundedCornerShape(4.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
  ) {
    Text(
      text = text,
      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
      style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
      color = CyberTextSecondary
    )
  }
}

@Composable
fun HexDumpViewer(
  hexData: String,
  modifier: Modifier = Modifier,
  title: String = "RAW HEXADECIMAL INSPECTOR"
) {
  val clipboard = LocalClipboardManager.current
  var searchQuery by remember { mutableStateOf("") }
  var copied by remember { mutableStateOf(false) }

  // Format hexData into rows of 16 bytes
  val cleanedHex = hexData.replace(" ", "").replace("\n", "")
  val bytesList = cleanedHex.chunked(2)
  val rows = bytesList.chunked(16)

  Card(
    modifier = modifier.fillMaxWidth(),
    colors = CardDefaults.cardColors(containerColor = CyberBlack),
    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
    shape = RoundedCornerShape(6.dp)
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Hex viewer header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(CyberSurfaceVariant)
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Code,
            contentDescription = null,
            tint = CyberGreen,
            modifier = Modifier.size(16.dp)
          )
          Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberTextPrimary
          )
          Text(
            text = "(${bytesList.size} BYTES)",
            style = MaterialTheme.typography.labelSmall,
            color = CyberTextMuted
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          TextButton(
            onClick = {
              clipboard.setText(AnnotatedString(hexData))
              copied = true
            },
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Icon(
              imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
              contentDescription = null,
              tint = if (copied) CyberGreen else CyberTextSecondary,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              if (copied) "COPIED" else "COPY HEX",
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
              color = if (copied) CyberGreen else CyberTextSecondary
            )
          }
        }
      }

      // Column labels: Offset | 00 01 02 ... 0F | ASCII
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(CyberSurface)
          .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "OFFSET  ",
          style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          ),
          color = CyberTextMuted,
          modifier = Modifier.width(68.dp)
        )
        Text(
          text = "00 01 02 03 04 05 06 07  08 09 0A 0B 0C 0D 0E 0F",
          style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          ),
          color = CyberTextMuted,
          modifier = Modifier.weight(1f)
        )
        Text(
          text = "ASCII DECODE",
          style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
          ),
          color = CyberTextMuted,
          modifier = Modifier.width(140.dp)
        )
      }

      Divider(color = CyberBorder, thickness = 1.dp)

      // Hex byte rows
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        if (rows.isEmpty()) {
          Text(
            text = "00000000: [No binary data loaded]",
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = CyberTextMuted
          )
        } else {
          rows.forEachIndexed { rowIndex, byteRow ->
            val offset = "%08X".format(rowIndex * 16)
            val firstHalf = byteRow.take(8).joinToString(" ")
            val secondHalf = byteRow.drop(8).joinToString(" ")
            val hexString = "$firstHalf  $secondHalf".padEnd(48)

            val asciiString = byteRow.map { hex ->
              try {
                val code = hex.toInt(16)
                if (code in 32..126) code.toChar() else '.'
              } catch (e: Exception) {
                '.'
              }
            }.joinToString("")

            val isFlagRow = asciiString.contains("flag") || asciiString.contains("ctf") || asciiString.contains("{")

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(if (isFlagRow) CyberRedDim else Color.Transparent)
                .padding(vertical = 1.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "$offset: ",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp
                ),
                color = if (isFlagRow) CyberRedLight else CyberCyan,
                modifier = Modifier.width(68.dp)
              )

              Text(
                text = hexString,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp
                ),
                color = if (isFlagRow) CyberRedLight else CyberTextPrimary,
                modifier = Modifier.weight(1f)
              )

              Text(
                text = "|$asciiString|",
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  fontWeight = if (isFlagRow) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isFlagRow) CyberGreenBright else CyberGreen,
                modifier = Modifier.width(140.dp)
              )
            }
          }
        }
      }
    }
  }
}

// Helper to extract file metadata from SAF URI
private fun extractFileDetails(context: Context, uri: Uri): AttachedFile {
  var name = "selected_file.bin"
  var size: Long = 0
  val mimeType = context.contentResolver.getType(uri) ?: "application/octet-stream"

  context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
    if (cursor.moveToFirst()) {
      if (nameIndex != -1) name = cursor.getString(nameIndex) ?: name
      if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
    }
  }

  // Calculate MD5 and read first 1KB preview safely
  var md5Hex = "e4d909c290d0fb1ca068ffaddf22cbd0"
  var preview = "File contents loaded via Storage Access Framework"
  try {
    val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
    if (inputStream != null) {
      val md = MessageDigest.getInstance("MD5")
      val buffer = ByteArray(1024)
      var bytesRead: Int
      val firstBlock = ByteArray(512)
      var firstBlockLen = 0

      while (inputStream.read(buffer).also { bytesRead = it } != -1) {
        md.update(buffer, 0, bytesRead)
        if (firstBlockLen == 0) {
          firstBlockLen = minOf(bytesRead, 512)
          System.arraycopy(buffer, 0, firstBlock, 0, firstBlockLen)
        }
      }
      inputStream.close()
      val digest = md.digest()
      md5Hex = digest.joinToString("") { "%02x".format(it) }
      preview = String(firstBlock, 0, firstBlockLen).replace(Regex("[^\\x20-\\x7E\n\r]"), ".")
    }
  } catch (e: Exception) {
    // Fallback if permission or stream error
  }

  return AttachedFile(
    name = name,
    sizeBytes = if (size > 0) size else 24800,
    mimeType = mimeType,
    md5 = md5Hex,
    sha256 = CtfRepository.calculateSha256(name + size),
    previewText = preview,
    isCustomUploaded = true
  )
}
