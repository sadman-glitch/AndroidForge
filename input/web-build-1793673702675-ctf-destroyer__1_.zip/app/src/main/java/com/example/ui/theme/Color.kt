package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF080A0F)
val CyberDarkBg = Color(0xFF0C1017)
val CyberSurface = Color(0xFF131924)
val CyberSurfaceVariant = Color(0xFF1B2333)
val CyberBorder = Color(0xFF26334A)
val CyberBorderRed = Color(0x66FF1744)
val CyberBorderGreen = Color(0x6600E676)

// Red accents
val CyberRed = Color(0xFFFF1744)
val CyberRedLight = Color(0xFFFF5252)
val CyberRedDark = Color(0xFFB71C1C)
val CyberRedDim = Color(0x33FF1744)

// Green highlights (Matrix / Terminal)
val CyberGreen = Color(0xFF00E676)
val CyberGreenBright = Color(0xFF69F0AE)
val CyberGreenDark = Color(0xFF00C853)
val CyberGreenDim = Color(0x2200E676)

// Secondary accents
val CyberCyan = Color(0xFF00E5FF)
val CyberYellow = Color(0xFFFFD600)
val CyberOrange = Color(0xFFFF9100)

// Text colors
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)

// Wireshark specific protocol row colors
val PcapHttpGreen = Color(0xFF1A382A)
val PcapDnsBlue = Color(0xFF162D4A)
val PcapTcpGrey = Color(0xFF1F2430)
val PcapIcmpPurple = Color(0xFF33203D)
val PcapArpYellow = Color(0xFF3D351A)
val PcapRstRed = Color(0xFF451A22)
