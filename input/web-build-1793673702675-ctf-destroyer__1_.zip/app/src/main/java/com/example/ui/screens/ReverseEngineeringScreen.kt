package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*

@Composable
fun ReverseEngineeringScreen(
  onNavigateBack: () -> Unit
) {
  var inputKey by remember { mutableStateOf("DESTROYER-2026-X89") }
  var crackmeResult by remember { mutableStateOf<String?>(null) }
  var isSolved by remember { mutableStateOf(false) }
  val clipboard = LocalClipboardManager.current

  fun runCrackme() {
    if (inputKey.trim() == "DESTROYER-2026-X89") {
      isSolved = true
      crackmeResult = "[+] CRACKME EMULATOR: validate_key(\"$inputKey\") -> 18/18 BYTES MATCH!\n[+] REGISTER RAX = 0x0 (SUCCESS)\n[+] WINNING FLAG: flag{r3v3rs1ng_b1n4ry_0pc0d3s}"
    } else {
      isSolved = false
      crackmeResult = "[-] CRACKME EMULATOR: validate_key(\"$inputKey\") -> MISMATCH!\n[-] REGISTER RAX = 0x1 (FAILED)\n[-] ACCESS DENIED: Invalid activation key."
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("reverse_engineering_screen")
  ) {
    CyberHeader(
      title = "GHIDRA BINARY DECOMPILER // CRACKME_V2.ELF (x86-64)",
      categoryBadge = "REVERSING",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            inputKey = "DESTROYER-2026-X89"
            runCrackme()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("load_known_key_button")
        ) {
          Text("SOLVE LICENSE CHECK", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag banner
    if (isSolved) {
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("rev_flag_banner"),
        color = CyberRedDark.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Verified, contentDescription = null, tint = CyberGreenBright, modifier = Modifier.size(16.dp))
            Text(
              text = "FLAG ACQUIRED: flag{r3v3rs1ng_b1n4ry_0pc0d3s}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberGreenBright
            )
          }
          Button(
            onClick = { clipboard.setText(AnnotatedString("flag{r3v3rs1ng_b1n4ry_0pc0d3s}")) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("COPY FLAG", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
          }
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: Disassembly Table (x86-64)
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(CyberSurfaceVariant)
              .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "DISASSEMBLY // .TEXT <main> & <validate_key>",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberYellow
            )
            Text(
              text = "ARCH: x86-64 ELF",
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
              color = CyberTextSecondary
            )
          }

          Divider(color = CyberBorder, thickness = 1.dp)

          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(6.dp)
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(2.dp)
          ) {
            CtfRepository.sampleDisassembly.forEach { instr ->
              val isTarget = instr.comment.contains("flag{") || instr.comment.contains("ACCESS GRANTED")
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(if (isTarget) CyberRedDim else Color.Transparent)
                  .padding(vertical = 1.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = instr.address,
                  style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                  color = CyberCyan,
                  modifier = Modifier.width(76.dp)
                )
                Text(
                  text = instr.opcode.padEnd(12),
                  style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                  color = CyberTextMuted,
                  modifier = Modifier.width(84.dp)
                )
                Text(
                  text = instr.instruction,
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  ),
                  color = if (isTarget) CyberRedLight else CyberTextPrimary,
                  modifier = Modifier.weight(1f)
                )
              }
            }
          }
        }
      }

      // Right Column: Decompiled Pseudocode (Upper) + Interactive Crackme (Lower)
      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Upper: Decompiled Pseudocode View
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1.2f),
          colors = CardDefaults.cardColors(containerColor = CyberBlack),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(modifier = Modifier.fillMaxSize()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(CyberSurfaceVariant)
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Code, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "GHIDRA DECOMPILED C PSEUDOCODE",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberGreenBright
              )
            }

            Divider(color = CyberBorder, thickness = 1.dp)

            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
            ) {
              Text(
                text = CtfRepository.decompiledCode,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  lineHeight = 15.sp
                ),
                color = CyberTextPrimary
              )
            }
          }
        }

        // Lower: Interactive Crackme Verification
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .weight(0.9f),
          colors = CardDefaults.cardColors(containerColor = CyberSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "CRACKME KEY VERIFICATION EMULATOR",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberRedLight
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              OutlinedTextField(
                value = inputKey,
                onValueChange = { inputKey = it },
                modifier = Modifier.weight(1f).height(48.dp).testTag("crackme_key_input"),
                placeholder = { Text("Enter license key to test (18 chars)...", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberYellow)
              )

              Button(
                onClick = { runCrackme() },
                colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                modifier = Modifier.height(48.dp).testTag("execute_crackme_button"),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text("RUN", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
              }
            }

            Surface(
              modifier = Modifier.fillMaxWidth().height(44.dp),
              color = CyberBlack,
              shape = RoundedCornerShape(4.dp),
              border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
              Text(
                text = crackmeResult ?: "[*] Ready. Enter license key and press RUN to emulate.",
                modifier = Modifier.padding(6.dp),
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 10.sp
                ),
                color = if (isSolved) CyberGreenBright else CyberTextSecondary
              )
            }
          }
        }
      }
    }
  }
}
