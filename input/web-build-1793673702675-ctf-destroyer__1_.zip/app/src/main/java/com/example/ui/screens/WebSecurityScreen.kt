package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*

@Composable
fun WebSecurityScreen(
  onNavigateBack: () -> Unit
) {
  var method by remember { mutableStateOf("POST") }
  var url by remember { mutableStateOf("http://internal-target.ctf.lan/api/admin") }
  var requestBody by remember { mutableStateOf("user=' OR '1'='1' -- -&pass=admin") }
  var responseStatus by remember { mutableStateOf("200 OK") }
  var responseBody by remember {
    mutableStateOf("""HTTP/1.1 200 OK
Server: Nginx/1.24.0 (Ubuntu)
Content-Type: application/json
Set-Cookie: ADMIN_AUTH=flag{sql_1nj3ct10n_byp4ss_pwnd}; Path=/; HttpOnly

{
  "status": "authenticated",
  "role": "superadmin",
  "welcome": "Welcome back, Admin Operator!",
  "flag": "flag{sql_1nj3ct10n_byp4ss_pwnd}"
}""")
  }
  val clipboard = LocalClipboardManager.current

  fun sendExploit(payloadStr: String) {
    if (payloadStr.contains("OR '1'='1'") || payloadStr.contains("UNION")) {
      responseStatus = "200 OK"
      responseBody = """HTTP/1.1 200 OK
Server: Nginx/1.24.0 (Ubuntu)
Content-Type: application/json
Set-Cookie: ADMIN_AUTH=flag{sql_1nj3ct10n_byp4ss_pwnd}; Path=/; HttpOnly

{
  "status": "authenticated",
  "role": "superadmin",
  "welcome": "Welcome back, Admin Operator!",
  "flag": "flag{sql_1nj3ct10n_byp4ss_pwnd}"
}"""
    } else if (payloadStr.contains("; cat")) {
      responseStatus = "200 OK"
      responseBody = """HTTP/1.1 200 OK
Content-Type: text/plain

PING 127.0.0.1 (127.0.0.1) 56(84) bytes of data.
64 bytes from 127.0.0.1: icmp_seq=1 ttl=64 time=0.034 ms
flag{rce_c0mm4nd_1nj3ct10n_pwn}"""
    } else if (payloadStr.contains("../")) {
      responseStatus = "200 OK"
      responseBody = """HTTP/1.1 200 OK
Content-Type: text/plain

root:x:0:0:root:/root:/bin/bash
daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
ctf_user:x:1001:1001:CTF Target User,,,:/home/ctf_user:/bin/bash
flag{p4th_tr4v3rs4l_r34d}"""
    } else {
      responseStatus = "401 Unauthorized"
      responseBody = """HTTP/1.1 401 Unauthorized
Content-Type: application/json

{"error": "Invalid credentials provided."}"""
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("web_security_screen")
  ) {
    CyberHeader(
      title = "BURP REPEATER & EXPLOIT LAB // TARGET: INTERNAL-TARGET.CTF.LAN",
      categoryBadge = "WEB SEC",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            requestBody = "user=' OR '1'='1' -- -&pass=dummy"
            sendExploit(requestBody)
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("load_sqli_payload_button")
        ) {
          Text("LOAD SQLi BYPASS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag banner
    if (responseBody.contains("flag{")) {
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("web_flag_banner"),
        color = CyberRedDark.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.BugReport, contentDescription = null, tint = CyberRedLight, modifier = Modifier.size(16.dp))
            Text(
              text = "FLAG REFLECTED: flag{sql_1nj3ct10n_byp4ss_pwnd}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberRedLight
            )
          }
          Button(
            onClick = { clipboard.setText(AnnotatedString("flag{sql_1nj3ct10n_byp4ss_pwnd}")) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("COPY FLAG", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
          }
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: Request Repeater & Payload Selector
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "HTTP REQUEST CRAFTER (BURP REPEATER)",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberOrange
          )

          // URL Bar & Method
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = if (method == "POST") CyberRedDark else CyberGreenDark,
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.clickable { method = if (method == "POST") "GET" else "POST" }
            ) {
              Text(
                text = method,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
              )
            }

            OutlinedTextField(
              value = url,
              onValueChange = { url = it },
              modifier = Modifier.weight(1f).height(48.dp),
              singleLine = true,
              textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberTextPrimary)
            )

            Button(
              onClick = { sendExploit(requestBody) },
              colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
              modifier = Modifier.height(48.dp).testTag("send_http_exploit_button"),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text("SEND", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
            }
          }

          Text(
            text = "PAYLOAD / FORM BODY:",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberTextSecondary
          )

          OutlinedTextField(
            value = requestBody,
            onValueChange = { requestBody = it },
            modifier = Modifier
              .fillMaxWidth()
              .height(90.dp)
              .testTag("http_request_body_input"),
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberYellow),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = CyberBlack,
              unfocusedContainerColor = CyberBlack,
              focusedBorderColor = CyberRed,
              unfocusedBorderColor = CyberBorder
            )
          )

          Text(
            text = "ATTACK PAYLOAD LIBRARY:",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberCyan
          )

          CtfRepository.webExploits.forEach { exploit ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  requestBody = exploit.payload
                  sendExploit(exploit.payload)
                }
                .padding(vertical = 2.dp),
              color = CyberSurfaceVariant,
              shape = RoundedCornerShape(4.dp),
              border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
            ) {
              Column(modifier = Modifier.padding(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = exploit.name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                  )
                  Text(
                    text = "[${exploit.category}]",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                    color = CyberOrange
                  )
                }
                Text(
                  text = exploit.payload,
                  style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                  color = CyberGreenBright
                )
              }
            }
          }
        }
      }

      // Right Column: HTTP Response Console
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberBlack),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(CyberSurfaceVariant)
              .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "SERVER HTTP RESPONSE // $responseStatus",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = if (responseStatus.startsWith("200")) CyberGreenBright else CyberRedLight
            )

            IconButton(
              onClick = { clipboard.setText(AnnotatedString(responseBody)) },
              modifier = Modifier.size(24.dp)
            ) {
              Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberTextSecondary, modifier = Modifier.size(14.dp))
            }
          }

          Divider(color = CyberBorder, thickness = 1.dp)

          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(8.dp)
              .verticalScroll(rememberScrollState())
          ) {
            responseBody.lines().forEach { line ->
              val isFlag = line.contains("flag{")
              Text(
                text = line,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  lineHeight = 15.sp,
                  fontWeight = if (isFlag) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isFlag) CyberRedLight else CyberTextPrimary
              )
            }
          }
        }
      }
    }
  }
}
