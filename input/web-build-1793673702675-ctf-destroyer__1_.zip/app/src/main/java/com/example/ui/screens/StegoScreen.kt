package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CyberHeader
import com.example.ui.components.HexDumpViewer
import com.example.ui.theme.*

@Composable
fun StegoScreen(
  onNavigateBack: () -> Unit
) {
  var selectedChannel by remember { mutableStateOf("Red 0 (LSB)") }
  var isExtracted by remember { mutableStateOf(false) }
  var extractedOutput by remember {
    mutableStateOf("""[*] StegSolve Engine v2.4 initialized.
[*] Analyzing target image: secret_agent_avatar.png (512x512 RGBA)
[*] Scanning Red bit plane 0...
[+] Detected non-random sub-pixel bitstream pattern!
[+] Extracted ASCII payload:
flag{st3g0_lsb_h1dd3n_d4t4}
[*] Appended ZIP archive detected at offset 0x14C80 (PK\x03\x04).""")
  }
  val clipboard = LocalClipboardManager.current

  val bitChannels = listOf(
    "Red 0 (LSB)", "Red 1", "Green 0 (LSB)", "Green 1",
    "Blue 0 (LSB)", "Blue 1", "Alpha 0", "Alpha 1"
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("stego_screen")
  ) {
    CyberHeader(
      title = "STEGANOGRAPHY LAB // SECRET_AGENT_AVATAR.PNG",
      categoryBadge = "STEGO",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            isExtracted = true
            extractedOutput = """[*] StegSolve Engine v2.4 initialized.
[*] Analyzing target image: secret_agent_avatar.png (512x512 RGBA)
[*] Scanning Red bit plane 0...
[+] Detected non-random sub-pixel bitstream pattern!
[+] Extracted ASCII payload:
flag{st3g0_lsb_h1dd3n_d4t4}
[*] Appended ZIP archive detected at offset 0x14C80 (PK\x03\x04)."""
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("extract_stego_button")
        ) {
          Text("EXTRACT LSB BITS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag banner
    Surface(
      modifier = Modifier.fillMaxWidth().testTag("stego_flag_banner"),
      color = CyberRedDark.copy(alpha = 0.4f),
      border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Icon(Icons.Default.Visibility, contentDescription = null, tint = CyberGreenBright, modifier = Modifier.size(16.dp))
          Text(
            text = "FLAG EXTRACTED: flag{st3g0_lsb_h1dd3n_d4t4}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberGreenBright
          )
        }
        Button(
          onClick = { clipboard.setText(AnnotatedString("flag{st3g0_lsb_h1dd3n_d4t4}")) },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
          modifier = Modifier.height(26.dp)
        ) {
          Text("COPY FLAG", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: Bit Plane Selector & Visualizer
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "SUB-PIXEL COLOR BIT PLANES (STEGSOLVE)",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberGreen
          )

          // Channel selector chips
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            bitChannels.take(4).forEach { channel ->
              val isSel = selectedChannel == channel
              Surface(
                modifier = Modifier
                  .weight(1f)
                  .clickable { selectedChannel = channel },
                color = if (isSel) CyberGreenDark else CyberSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) CyberGreen else CyberBorder),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = channel,
                  modifier = Modifier.padding(vertical = 6.dp),
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                  color = if (isSel) CyberTextPrimary else CyberTextSecondary,
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            bitChannels.drop(4).forEach { channel ->
              val isSel = selectedChannel == channel
              Surface(
                modifier = Modifier
                  .weight(1f)
                  .clickable { selectedChannel = channel },
                color = if (isSel) CyberGreenDark else CyberSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) CyberGreen else CyberBorder),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = channel,
                  modifier = Modifier.padding(vertical = 6.dp),
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                  color = if (isSel) CyberTextPrimary else CyberTextSecondary,
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
              }
            }
          }

          // Bit plane preview simulation (matrix visual)
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .height(130.dp),
            color = CyberBlack,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
          ) {
            Column(
              modifier = Modifier.padding(8.dp),
              verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
              Text(
                text = "SIMULATED BIT PLANE RASTER: $selectedChannel",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                color = CyberYellow
              )
              Text(
                text = "01100110 01101100 01100001 01100111 01111011 01110011 01110100 00110011\n01100111 00110000 01011111 01101100 01110011 01100010 01011111 01101000\n00110001 01100100 01100100 00110011 01101110 01011111 01100100 00110100\n01110100 00110100 01111101 [BINARY STREAM MATCH]",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                color = CyberGreenBright
              )
            }
          }
        }
      }

      // Right Column: Extracted Bitstream & Carved Archive
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberBlack),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(CyberSurfaceVariant)
              .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Terminal, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "ZSTEG & FOREMOST EXTRACTION LOG",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberTextPrimary
            )
          }

          Divider(color = CyberBorder, thickness = 1.dp)

          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(8.dp)
              .verticalScroll(rememberScrollState())
          ) {
            extractedOutput.lines().forEach { line ->
              val isFlag = line.contains("flag{")
              Text(
                text = line,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  lineHeight = 15.sp,
                  fontWeight = if (isFlag) FontWeight.Bold else FontWeight.Normal
                ),
                color = if (isFlag) CyberGreenBright else CyberTextPrimary
              )
            }
          }
        }
      }
    }
  }
}
