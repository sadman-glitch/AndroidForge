package com.example.ui.screens

import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*

@Composable
fun CryptoScreen(
  onNavigateBack: () -> Unit
) {
  var inputText by remember { mutableStateOf("ZmxhZ3tyMHRfdGhpcnRlZW5fc3VwM3JfY3J5cHQwfQ==") }
  var outputText by remember { mutableStateOf("flag{r0t_thirteen_sup3r_crypt0}") }
  var caesarShift by remember { mutableFloatStateOf(13f) }
  var xorKey by remember { mutableStateOf("X") }
  var activeTab by remember { mutableIntStateOf(0) } // 0: Base64, 1: Caesar/ROT, 2: XOR, 3: Hex, 4: Hashes
  val clipboard = LocalClipboardManager.current

  // Real-time calculations
  fun decodeBase64() {
    try {
      val decoded = Base64.decode(inputText.trim(), Base64.DEFAULT)
      outputText = String(decoded, Charsets.UTF_8)
    } catch (e: Exception) {
      outputText = "[-] Error: Invalid Base64 payload."
    }
  }

  fun encodeBase64() {
    val encoded = Base64.encodeToString(inputText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    outputText = encoded
  }

  fun applyCaesar() {
    outputText = CtfRepository.rot13(inputText, caesarShift.toInt())
  }

  fun applyXor() {
    val keyChar = xorKey.firstOrNull() ?: 'A'
    outputText = CtfRepository.xorString(inputText, keyChar)
  }

  fun hexToAscii() {
    try {
      val clean = inputText.replace(" ", "").replace("0x", "")
      val bytes = clean.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
      outputText = String(bytes, Charsets.UTF_8)
    } catch (e: Exception) {
      outputText = "[-] Error: Invalid Hex string."
    }
  }

  fun asciiToHex() {
    outputText = inputText.map { "%02X".format(it.code) }.joinToString(" ")
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("crypto_screen")
  ) {
    CyberHeader(
      title = "CRYPTOGRAPHIC WORKBENCH // CIPHER BREAKER",
      categoryBadge = "CRYPTO",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            inputText = "ZmxhZ3tyMHRfdGhpcnRlZW5fc3VwM3JfY3J5cHQwfQ=="
            decodeBase64()
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("load_sample_crypto_button")
        ) {
          Text("LOAD SAMPLE CIPHER", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag Alert if output has flag
    if (outputText.contains("flag{")) {
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("crypto_flag_banner"),
        color = CyberRedDark.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.VpnKey, contentDescription = null, tint = CyberRedLight, modifier = Modifier.size(16.dp))
            Text(
              text = "FLAG DECRYPTED: $outputText",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberRedLight
            )
          }
          Button(
            onClick = { clipboard.setText(AnnotatedString(outputText)) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
            shape = RoundedCornerShape(4.dp),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
            modifier = Modifier.height(26.dp)
          ) {
            Text("COPY FLAG", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
          }
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(10.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      // Left Column: Cipher Operations & Input (Width ~50%)
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(6.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Text(
            text = "INPUT PAYLOAD / CIPHERTEXT",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberCyan
          )

          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            modifier = Modifier
              .fillMaxWidth()
              .height(90.dp)
              .testTag("crypto_input_text"),
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberTextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = CyberRed,
              unfocusedBorderColor = CyberBorder,
              focusedContainerColor = CyberBlack,
              unfocusedContainerColor = CyberBlack
            ),
            shape = RoundedCornerShape(4.dp)
          )

          // Operation Selector Tabs
          TabRow(
            selectedTabIndex = activeTab,
            containerColor = CyberSurfaceVariant,
            contentColor = CyberRed
          ) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("BASE64", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("CAESAR / ROT", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("XOR KEY", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = activeTab == 3, onClick = { activeTab = 3 }, text = { Text("HEX", style = MaterialTheme.typography.labelSmall) })
            Tab(selected = activeTab == 4, onClick = { activeTab = 4 }, text = { Text("HASHES", style = MaterialTheme.typography.labelSmall) })
          }

          // Tab-specific controls
          when (activeTab) {
            0 -> {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = { decodeBase64() },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("DECODE BASE64", color = CyberBlack, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
                OutlinedButton(
                  onClick = { encodeBase64() },
                  border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("ENCODE BASE64", color = CyberTextPrimary, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
            1 -> {
              Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("SHIFT OFFSET: ${caesarShift.toInt()} (ROT-${caesarShift.toInt()})", style = MaterialTheme.typography.labelSmall, color = CyberYellow)
                }
                Slider(
                  value = caesarShift,
                  onValueChange = {
                    caesarShift = it
                    applyCaesar()
                  },
                  valueRange = 1f..25f,
                  steps = 23,
                  colors = SliderDefaults.colors(thumbColor = CyberRed, activeTrackColor = CyberRedLight)
                )
                Button(
                  onClick = { applyCaesar() },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Text("APPLY ROT SHIFT", color = CyberBlack, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
              }
            }
            2 -> {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                OutlinedTextField(
                  value = xorKey,
                  onValueChange = { if (it.length <= 1) xorKey = it },
                  label = { Text("SINGLE-BYTE XOR KEY") },
                  modifier = Modifier.width(130.dp),
                  singleLine = true,
                  textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberYellow)
                )
                Button(
                  onClick = { applyXor() },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberYellow),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("EXECUTE XOR OPERATION", color = CyberBlack, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
              }
            }
            3 -> {
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                  onClick = { hexToAscii() },
                  colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("HEX -> ASCII", color = CyberBlack, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
                OutlinedButton(
                  onClick = { asciiToHex() },
                  border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                  modifier = Modifier.weight(1f)
                ) {
                  Text("ASCII -> HEX", color = CyberTextPrimary, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
            4 -> {
              Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("MD5: ${CtfRepository.calculateMd5(inputText)}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = CyberCyan)
                Text("SHA-256: ${CtfRepository.calculateSha256(inputText)}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = CyberGreenBright)
              }
            }
          }
        }
      }

      // Right Column: Output & Decryption Result (Width ~50%)
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberBlack),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(6.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "DECRYPTED STREAM / PLAIN TRANSFORM",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberGreen
              )

              IconButton(
                onClick = { clipboard.setText(AnnotatedString(outputText)) },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberTextSecondary, modifier = Modifier.size(16.dp))
              }
            }

            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 140.dp)
                .border(1.dp, CyberBorder, RoundedCornerShape(4.dp)),
              color = CyberSurface
            ) {
              Text(
                text = outputText,
                modifier = Modifier.padding(10.dp),
                style = MaterialTheme.typography.bodyMedium.copy(
                  fontFamily = FontFamily.Monospace,
                  color = if (outputText.contains("flag{")) CyberRedLight else CyberTextPrimary
                )
              )
            }
          }

          // Bottom CTF Helper Hint
          Surface(
            color = CyberSurfaceVariant,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
          ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = "CYBERCHEF HEURISTIC ADVISOR:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberYellow
              )
              Text(
                text = "Payload 'ZmxhZ...' detected as standard Base64 string with 'flag{' prefix. Decoded to 'flag{r0t_thirteen_sup3r_crypt0}'.",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = CyberTextSecondary
              )
            }
          }
        }
      }
    }
  }
}
