package com.example

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.data.CtfRepository
import com.example.model.AttachedFile
import com.example.model.Screen
import com.example.ui.screens.*
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    // Force sensor-aware landscape orientation
    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding(),
          color = CyberBlack
        ) {
          CtfApp()
        }
      }
    }
  }
}

@Composable
fun CtfApp() {
  var currentScreen by remember { mutableStateOf(Screen.WARNING) }
  var operatorName by remember { mutableStateOf("ROOT") }
  var currentFile by remember { mutableStateOf<AttachedFile?>(CtfRepository.sampleFiles.first()) }
  var challengeDesc by remember {
    mutableStateOf("Examine intercepted HTTP POST request for exfiltrated credentials and flag format flag{...}")
  }

  // Handle system back button for all sub-screens
  BackHandler(enabled = currentScreen != Screen.WARNING) {
    when (currentScreen) {
      Screen.LOGIN -> currentScreen = Screen.WARNING
      Screen.DASHBOARD -> currentScreen = Screen.LOGIN
      else -> currentScreen = Screen.DASHBOARD
    }
  }

  AnimatedContent(
    targetState = currentScreen,
    transitionSpec = {
      fadeIn() togetherWith fadeOut()
    },
    label = "ScreenTransition"
  ) { screen ->
    when (screen) {
      Screen.WARNING -> {
        WarningScreen(
          onAcceptAndProceed = {
            currentScreen = Screen.LOGIN
          }
        )
      }

      Screen.LOGIN -> {
        LoginScreen(
          onLoginSuccess = { user ->
            operatorName = user.uppercase()
            currentScreen = Screen.DASHBOARD
          }
        )
      }

      Screen.DASHBOARD -> {
        DashboardScreen(
          operatorName = operatorName,
          currentFile = currentFile,
          onFileSelected = { file -> currentFile = file },
          challengeDesc = challengeDesc,
          onChallengeDescChange = { desc -> challengeDesc = desc },
          onNavigateToScreen = { target -> currentScreen = target },
          onRunAiSolver = { currentScreen = Screen.AI_SOLVER },
          onLogout = { currentScreen = Screen.LOGIN }
        )
      }

      Screen.FORENSICS -> {
        ForensicsScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.NETWORKING -> {
        NetworkingScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.CRYPTOGRAPHY -> {
        CryptoScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.REVERSE_ENGINEERING -> {
        ReverseEngineeringScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.WEB_SECURITY -> {
        WebSecurityScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.STEGANOGRAPHY -> {
        StegoScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.OSINT -> {
        OsintScreen(
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }

      Screen.AI_SOLVER -> {
        AiSolverScreen(
          currentFile = currentFile,
          challengeDesc = challengeDesc,
          onNavigateBack = { currentScreen = Screen.DASHBOARD }
        )
      }
    }
  }
}
