package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CyberColorScheme = darkColorScheme(
  primary = CyberRed,
  onPrimary = CyberBlack,
  primaryContainer = CyberRedDark,
  onPrimaryContainer = CyberTextPrimary,
  secondary = CyberGreen,
  onSecondary = CyberBlack,
  secondaryContainer = CyberGreenDark,
  onSecondaryContainer = CyberTextPrimary,
  tertiary = CyberCyan,
  onTertiary = CyberBlack,
  background = CyberBlack,
  onBackground = CyberTextPrimary,
  surface = CyberSurface,
  onSurface = CyberTextPrimary,
  surfaceVariant = CyberSurfaceVariant,
  onSurfaceVariant = CyberTextSecondary,
  outline = CyberBorder,
  outlineVariant = CyberBorderRed,
  error = CyberRedLight,
  onError = CyberBlack
)

@Composable
fun MyApplicationTheme(
  content: @Composable () -> Unit
) {
  // Always use the curated Cyberpunk CTF dark theme for immersive cybersecurity operations
  MaterialTheme(
    colorScheme = CyberColorScheme,
    typography = Typography,
    content = content
  )
}
