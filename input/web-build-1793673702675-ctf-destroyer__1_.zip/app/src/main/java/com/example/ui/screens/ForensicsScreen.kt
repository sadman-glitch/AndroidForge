package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.model.ForensicItem
import com.example.model.ForensicType
import com.example.ui.components.CyberHeader
import com.example.ui.components.HexDumpViewer
import com.example.ui.theme.*

@Composable
fun ForensicsScreen(
  onNavigateBack: () -> Unit
) {
  var selectedItem by remember { mutableStateOf(CtfRepository.sampleForensicItems.first()) }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Hex, 1: Strings, 2: Metadata, 3: Carver
  var filterCategory by remember { mutableStateOf<ForensicType?>(null) }
  var isCarvingRunning by remember { mutableStateOf(false) }
  var carvedSuccessMessage by remember { mutableStateOf<String?>(null) }
  val clipboard = LocalClipboardManager.current

  val items = remember(filterCategory) {
    if (filterCategory == null) CtfRepository.sampleForensicItems
    else CtfRepository.sampleForensicItems.filter { it.type == filterCategory }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("forensics_screen")
  ) {
    // Header
    CyberHeader(
      title = "AUTOPSY DIGITAL FORENSICS // SDB1_INVESTIGATION.RAW",
      categoryBadge = "FORENSICS",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = {
            isCarvingRunning = true
            carvedSuccessMessage = "CARVER COMPLETE: Recovered 'flag_backup.png' -> ${selectedItem.extractedFlag ?: "flag{4ut0psy_c4rv3d_my_s3cr3ts}"}"
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("autopsy_carve_button")
        ) {
          Icon(Icons.Default.ContentCut, contentDescription = null, tint = CyberBlack, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("CARVE UNALLOCATED CLUSTERS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Flag banner if carved or selected item has a flag
    if (selectedItem.extractedFlag != null || carvedSuccessMessage != null) {
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("forensic_flag_banner"),
        color = CyberRedDark.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Flag, contentDescription = null, tint = CyberRedLight, modifier = Modifier.size(16.dp))
            Text(
              text = "FLAG RECOVERED: ${selectedItem.extractedFlag ?: "flag{4ut0psy_c4rv3d_my_s3cr3ts}"}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberRedLight
            )
          }

          TextButton(
            onClick = {
              clipboard.setText(AnnotatedString(selectedItem.extractedFlag ?: "flag{4ut0psy_c4rv3d_my_s3cr3ts}"))
            },
            modifier = Modifier.height(26.dp),
            contentPadding = PaddingValues(horizontal = 8.dp)
          ) {
            Text("COPY FLAG", style = MaterialTheme.typography.labelSmall, color = CyberGreenBright)
          }
        }
      }
    }

    // Main 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: Autopsy Data Source & Artifact Tree (Width ~280dp)
      Card(
        modifier = Modifier
          .width(280.dp)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Icon(Icons.Default.FolderOpen, contentDescription = null, tint = CyberYellow, modifier = Modifier.size(16.dp))
            Text(
              text = "DATA SOURCES & ARTIFACTS",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberTextPrimary
            )
          }

          Divider(color = CyberBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

          // Tree root
          TreeItemRow(
            title = "sdb1_investigation.raw (FAT32)",
            icon = Icons.Default.Storage,
            badge = "100 MB",
            isSelected = filterCategory == null,
            onClick = { filterCategory = null }
          )

          Text(
            text = "EXTRACTED ARTIFACT CATEGORIES:",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = CyberTextMuted,
            modifier = Modifier.padding(top = 4.dp, start = 4.dp)
          )

          TreeItemRow(
            title = "Deleted & Carved Files",
            icon = Icons.Default.DeleteSweep,
            badge = "1",
            isSelected = filterCategory == ForensicType.DELETED_FILE,
            onClick = { filterCategory = ForensicType.DELETED_FILE }
          )

          TreeItemRow(
            title = "Web History & Cache",
            icon = Icons.Default.History,
            badge = "1",
            isSelected = filterCategory == ForensicType.WEB_HISTORY,
            onClick = { filterCategory = ForensicType.WEB_HISTORY }
          )

          TreeItemRow(
            title = "System Registry Hives",
            icon = Icons.Default.SettingsSystemDaydream,
            badge = "1",
            isSelected = filterCategory == ForensicType.SYSTEM_REGISTRY,
            onClick = { filterCategory = ForensicType.SYSTEM_REGISTRY }
          )

          TreeItemRow(
            title = "EXIF Geospatial Meta",
            icon = Icons.Default.LocationOn,
            badge = "1",
            isSelected = filterCategory == ForensicType.EXIF_METADATA,
            onClick = { filterCategory = ForensicType.EXIF_METADATA }
          )

          TreeItemRow(
            title = "Executables & Malware",
            icon = Icons.Default.BugReport,
            badge = "1",
            isSelected = filterCategory == ForensicType.EXECUTABLE_BINARY,
            onClick = { filterCategory = ForensicType.EXECUTABLE_BINARY }
          )

          Divider(color = CyberBorder, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

          Text(
            text = "EVIDENCE ITEMS:",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
            color = CyberTextMuted,
            modifier = Modifier.padding(start = 4.dp)
          )

          items.forEach { item ->
            val isCurrent = selectedItem.id == item.id
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .clickable { selectedItem = item }
                .padding(vertical = 2.dp),
              color = if (isCurrent) CyberRedDim else CyberSurfaceVariant,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (isCurrent) CyberRed else Color.Transparent),
              shape = RoundedCornerShape(4.dp)
            ) {
              Column(modifier = Modifier.padding(6.dp)) {
                Text(
                  text = item.name,
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                  ),
                  color = if (isCurrent) CyberRedLight else CyberTextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
                Text(
                  text = "${item.size} • ${item.status}",
                  style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                  color = if (item.extractedFlag != null) CyberGreenBright else CyberTextMuted
                )
              }
            }
          }
        }
      }

      // Right Column: Autopsy Metadata Table (Upper) & Content Viewer Tabs (Lower)
      Column(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Upper: Selected Forensic Item Details & Hash Box
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = CyberSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "SELECTED: ${selectedItem.name}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberCyan
              )
              Surface(
                color = if (selectedItem.status.contains("Carved")) CyberGreenDim else CyberSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedItem.status.contains("Carved")) CyberGreen else CyberBorder),
                shape = RoundedCornerShape(4.dp)
              ) {
                Text(
                  text = selectedItem.status,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  style = MaterialTheme.typography.labelSmall,
                  color = if (selectedItem.status.contains("Carved")) CyberGreenBright else CyberTextSecondary
                )
              }
            }

            Text(
              text = "Path: ${selectedItem.path}",
              style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 11.sp),
              color = CyberTextSecondary
            )

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
              Text(
                text = "MD5: ${selectedItem.md5}",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                color = CyberTextMuted
              )
              Text(
                text = "Created: ${selectedItem.created}",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                color = CyberTextMuted
              )
            }
          }
        }

        // Lower: Autopsy Tabs Viewer (Hex, Strings, Metadata, Carver)
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          colors = CardDefaults.cardColors(containerColor = CyberBlack),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(modifier = Modifier.fillMaxSize()) {
            // Tab Row
            TabRow(
              selectedTabIndex = selectedTab,
              containerColor = CyberSurfaceVariant,
              contentColor = CyberRed
            ) {
              Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("HEX DUMP", style = MaterialTheme.typography.labelSmall) }
              )
              Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("STRINGS EXTRACTOR", style = MaterialTheme.typography.labelSmall) }
              )
              Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("METADATA & ATTRIBUTES", style = MaterialTheme.typography.labelSmall) }
              )
              Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("FILE CARVER RESULTS", style = MaterialTheme.typography.labelSmall) }
              )
            }

            // Tab Content
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
            ) {
              when (selectedTab) {
                0 -> {
                  HexDumpViewer(
                    hexData = selectedItem.hexSnippet,
                    modifier = Modifier.fillMaxSize(),
                    title = "${selectedItem.name} // HEX PREVIEW"
                  )
                }
                1 -> {
                  Column(
                    modifier = Modifier
                      .fillMaxSize()
                      .verticalScroll(rememberScrollState())
                      .background(CyberBlack, RoundedCornerShape(4.dp))
                      .border(1.dp, CyberBorder, RoundedCornerShape(4.dp))
                      .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                  ) {
                    Text(
                      text = "// EXTRACTED ASCII & UTF-8 STRINGS SCAN (MIN LEN 4):",
                      style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                      color = CyberGreen
                    )
                    selectedItem.stringsContent.lines().forEach { line ->
                      val isFlag = line.contains("flag{")
                      Text(
                        text = line,
                        style = MaterialTheme.typography.bodySmall.copy(
                          fontFamily = FontFamily.Monospace,
                          fontSize = 11.sp,
                          fontWeight = if (isFlag) FontWeight.Bold else FontWeight.Normal
                        ),
                        color = if (isFlag) CyberRedLight else CyberTextPrimary
                      )
                    }
                  }
                }
                2 -> {
                  Column(
                    modifier = Modifier
                      .fillMaxSize()
                      .verticalScroll(rememberScrollState())
                      .background(CyberSurface, RoundedCornerShape(4.dp))
                      .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                  ) {
                    Text(
                      text = "FILESYSTEM INODE & METADATA ATTRIBUTES:",
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = CyberYellow
                    )
                    selectedItem.metadataAttributes.forEach { (key, value) ->
                      Row(
                        modifier = Modifier
                          .fillMaxWidth()
                          .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Text(
                          text = "$key: ",
                          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                          color = CyberTextSecondary
                        )
                        Text(
                          text = value,
                          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                          color = CyberTextPrimary
                        )
                      }
                      Divider(color = CyberBorder, thickness = 0.5.dp)
                    }
                  }
                }
                3 -> {
                  Column(
                    modifier = Modifier
                      .fillMaxSize()
                      .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                  ) {
                    Surface(
                      color = CyberGreenDim,
                      border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderGreen),
                      shape = RoundedCornerShape(4.dp)
                    ) {
                      Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                          text = "AUTOPSY CARVER ENGINE // SCALPEL v2.1 COMPLETED",
                          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                          color = CyberGreenBright
                        )
                        Text(
                          text = "Scanned 100,000 sectors. Found 1 orphaned file matching PNG magic bytes '89 50 4E 47' with valid IEND trailer.",
                          style = MaterialTheme.typography.bodySmall,
                          color = CyberTextPrimary
                        )
                        Text(
                          text = "Recovered Artifact: flag_backup.png.deleted (Offset: 0x00412000)",
                          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                          color = CyberCyan
                        )
                        Text(
                          text = "Extracted Flag: flag{4ut0psy_c4rv3d_my_s3cr3ts}",
                          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                          color = CyberRedLight
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun TreeItemRow(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  badge: String,
  isSelected: Boolean,
  onClick: () -> Unit
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 1.dp),
    color = if (isSelected) CyberRedDim else Color.Transparent,
    shape = RoundedCornerShape(4.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 6.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.weight(1f)
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (isSelected) CyberRedLight else CyberTextSecondary,
          modifier = Modifier.size(16.dp)
        )
        Text(
          text = title,
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
          ),
          color = if (isSelected) CyberRedLight else CyberTextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      Surface(
        color = CyberSurfaceVariant,
        shape = RoundedCornerShape(3.dp)
      ) {
        Text(
          text = badge,
          modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
          style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
          color = CyberTextMuted
        )
      }
    }
  }
}
