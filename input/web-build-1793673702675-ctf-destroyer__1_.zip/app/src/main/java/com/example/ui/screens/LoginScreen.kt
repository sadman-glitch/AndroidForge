package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun LoginScreen(
  onLoginSuccess: (operatorName: String) -> Unit
) {
  var username by remember { mutableStateOf("operator_root") }
  var password by remember { mutableStateOf("cyber_destroyer_2026") }
  var passwordVisible by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(false) }

  fun executeLogin(user: String, pass: String) {
    if (user.isBlank()) {
      errorMessage = "[-] ERROR: Operator Codename cannot be empty."
      return
    }
    if (pass.isBlank()) {
      errorMessage = "[-] ERROR: Access Key / Passphrase cannot be empty."
      return
    }

    isLoading = true
    errorMessage = null
    // Successful login
    onLoginSuccess(user.trim())
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.linearGradient(
          colors = listOf(CyberBlack, Color(0xFF0F141E), CyberBlack)
        )
      )
      .testTag("login_screen")
  ) {
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(24.dp),
      horizontalArrangement = Arrangement.spacedBy(24.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left side: Insignia and system status
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
          verticalArrangement = Arrangement.SpaceBetween,
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              color = CyberRedDark.copy(alpha = 0.3f),
              border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed),
              shape = RoundedCornerShape(4.dp)
            ) {
              Text(
                text = "SECURITY PROTOCOL v4.2",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall,
                color = CyberRedLight
              )
            }

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Box(
                modifier = Modifier
                  .size(8.dp)
                  .clip(RoundedCornerShape(4.dp))
                  .background(CyberGreen)
              )
              Text(
                text = "ONLINE",
                style = MaterialTheme.typography.labelSmall,
                color = CyberGreen
              )
            }
          }

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Surface(
              modifier = Modifier.size(76.dp),
              shape = RoundedCornerShape(16.dp),
              color = CyberBlack,
              border = androidx.compose.foundation.BorderStroke(2.dp, CyberRed)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.Terminal,
                  contentDescription = "Terminal Insignia",
                  tint = CyberRed,
                  modifier = Modifier.size(44.dp)
                )
              }
            }

            Text(
              text = "CTF DESTROYER",
              style = MaterialTheme.typography.displayMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp
              ),
              color = CyberRedLight
            )

            Text(
              text = "TACTICAL CYBER DEFENSE & CTF SUITE",
              style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp),
              color = CyberTextSecondary
            )
          }

          // Security specs list
          Surface(
            modifier = Modifier.fillMaxWidth(),
            color = CyberBlack,
            shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
          ) {
            Column(
              modifier = Modifier.padding(10.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = "• WIRESHARK PACKET ANALYSIS ENGINE",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = CyberGreen
              )
              Text(
                text = "• AUTOPSY DIGITAL FORENSICS WORKBENCH",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = CyberGreen
              )
              Text(
                text = "• MULTI-STAGE CRYPTO & REVERSING LAB",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = CyberGreen
              )
              Text(
                text = "• NEURAL HEURISTIC AI CTF AUTO SOLVER",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = CyberGreenBright
              )
            }
          }
        }
      }

      // Right side: Authentication Form
      Card(
        modifier = Modifier
          .weight(1.1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
          verticalArrangement = Arrangement.SpaceBetween
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "OPERATOR CREDENTIALS",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = CyberTextPrimary
            )
            Text(
              text = "Authenticate your session to gain root access to the CTF sandbox.",
              style = MaterialTheme.typography.bodySmall,
              color = CyberTextSecondary
            )
          }

          Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Username field
            OutlinedTextField(
              value = username,
              onValueChange = {
                username = it
                errorMessage = null
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("login_username_input"),
              label = { Text("OPERATOR CODENAME / USERNAME", style = MaterialTheme.typography.labelSmall) },
              leadingIcon = {
                Icon(Icons.Default.Person, contentDescription = null, tint = CyberRed)
              },
              textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                color = CyberTextPrimary
              ),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberRed,
                unfocusedBorderColor = CyberBorder,
                focusedContainerColor = CyberBlack,
                unfocusedContainerColor = CyberBlack
              ),
              singleLine = true,
              shape = RoundedCornerShape(8.dp),
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
            )

            // Password field
            OutlinedTextField(
              value = password,
              onValueChange = {
                password = it
                errorMessage = null
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("login_password_input"),
              label = { Text("ACCESS PASSPHRASE / KEY", style = MaterialTheme.typography.labelSmall) },
              leadingIcon = {
                Icon(Icons.Default.VpnKey, contentDescription = null, tint = CyberRed)
              },
              trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                  Icon(
                    imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = "Toggle Password Visibility",
                    tint = CyberTextSecondary
                  )
                }
              },
              visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
              textStyle = MaterialTheme.typography.bodyMedium.copy(
                fontFamily = FontFamily.Monospace,
                color = CyberTextPrimary
              ),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberRed,
                unfocusedBorderColor = CyberBorder,
                focusedContainerColor = CyberBlack,
                unfocusedContainerColor = CyberBlack
              ),
              singleLine = true,
              shape = RoundedCornerShape(8.dp),
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
              keyboardActions = KeyboardActions(
                onDone = { executeLogin(username, password) }
              )
            )

            // Error or feedback banner
            if (errorMessage != null) {
              Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CyberRedDark.copy(alpha = 0.3f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = errorMessage ?: "",
                  modifier = Modifier.padding(8.dp),
                  style = MaterialTheme.typography.bodySmall,
                  color = CyberRedLight
                )
              }
            }
          }

          // Buttons row: Guest Quick Access + Primary Authenticate
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = {
                username = "guest_researcher"
                password = "sandbox_demo_access"
                executeLogin(username, password)
              },
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("login_guest_button"),
              border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderGreen),
              shape = RoundedCornerShape(8.dp)
            ) {
              Icon(
                Icons.Default.PersonOutline,
                contentDescription = null,
                tint = CyberGreen,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "DEMO ACCESS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberGreen
              )
            }

            Button(
              onClick = { executeLogin(username, password) },
              modifier = Modifier
                .weight(1.4f)
                .height(48.dp)
                .testTag("login_submit_button"),
              colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
              shape = RoundedCornerShape(8.dp),
              enabled = !isLoading
            ) {
              if (isLoading) {
                CircularProgressIndicator(
                  modifier = Modifier.size(16.dp),
                  color = CyberBlack,
                  strokeWidth = 2.dp
                )
              } else {
                Icon(
                  Icons.Default.Login,
                  contentDescription = null,
                  tint = CyberBlack,
                  modifier = Modifier.size(18.dp)
                )
              }
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                "AUTHENTICATE OPERATOR",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = CyberBlack
              )
            }
          }
        }
      }
    }
  }
}
