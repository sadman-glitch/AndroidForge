package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.model.AiSolveReport
import com.example.model.AttachedFile
import com.example.ui.components.CyberHeader
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun AiSolverScreen(
  currentFile: AttachedFile?,
  challengeDesc: String,
  onNavigateBack: () -> Unit
) {
  val coroutineScope = rememberCoroutineScope()
  var isSolving by remember { mutableStateOf(false) }
  var report by remember {
    mutableStateOf(
      CtfRepository.runAiSolvePipeline(
        challengeDesc = if (challengeDesc.isNotBlank()) challengeDesc else "Find the exfiltrated flag in the HTTP traffic.",
        attachedFile = currentFile ?: CtfRepository.sampleFiles.first()
      )
    )
  }
  val clipboard = LocalClipboardManager.current
  var copied by remember { mutableStateOf(false) }

  fun executeAiPipeline() {
    isSolving = true
    coroutineScope.launch {
      delay(400) // Brief simulation of neural pipeline
      report = CtfRepository.runAiSolvePipeline(
        challengeDesc = challengeDesc,
        attachedFile = currentFile
      )
      isSolving = false
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("ai_solver_screen")
  ) {
    CyberHeader(
      title = "NEURAL HEURISTIC CTF SOLVER // AI AUTO SOLVER",
      categoryBadge = "AI ENGINE",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = { executeAiPipeline() },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("trigger_ai_pipeline_button"),
          enabled = !isSolving
        ) {
          if (isSolving) {
            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = CyberBlack, strokeWidth = 2.dp)
          } else {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CyberBlack, modifier = Modifier.size(16.dp))
          }
          Spacer(modifier = Modifier.width(4.dp))
          Text(if (isSolving) "ANALYZING..." else "RUN AI PIPELINE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Target Overview Bar
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = CyberSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.Memory, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(16.dp))
          Text(
            text = "TARGET: ${currentFile?.name ?: "Interactive Description Prompt"}",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberTextPrimary
          )
          Text(
            text = "• FORMAT: ${report.detectedFormat}",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = CyberCyan
          )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "CONFIDENCE: ${report.confidenceScore}%",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = CyberGreenBright
          )
          Text(
            text = "EXEC TIME: ${report.executionTimeMs} ms",
            style = MaterialTheme.typography.labelSmall,
            color = CyberTextSecondary
          )
        }
      }
    }

    // 2-Column Split Landscape Layout
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      // Left Column: 4-Stage Live Analysis Execution Pipeline
      Card(
        modifier = Modifier
          .weight(1f)
          .fillMaxHeight(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.AccountTree, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(16.dp))
            Text(
              text = "MULTI-STAGE AUTOMATED PIPELINE EXECUTION",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberTextPrimary
            )
          }

          Divider(color = CyberBorder, thickness = 1.dp)

          report.stages.forEachIndexed { index, stage ->
            Surface(
              modifier = Modifier.fillMaxWidth(),
              color = CyberSurfaceVariant,
              border = androidx.compose.foundation.BorderStroke(1.dp, if (stage.status == "SUCCESS") CyberBorderGreen else CyberBorder),
              shape = RoundedCornerShape(4.dp)
            ) {
              Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = stage.name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = CyberTextPrimary
                  )
                  Surface(
                    color = if (stage.status == "SUCCESS") CyberGreenDark else CyberSurface,
                    shape = RoundedCornerShape(3.dp)
                  ) {
                    Text(
                      text = stage.status,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                      color = if (stage.status == "SUCCESS") CyberGreenBright else CyberTextMuted
                    )
                  }
                }
                Text(
                  text = stage.finding,
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                  ),
                  color = CyberTextSecondary
                )
              }
            }
          }
        }
      }

      // Right Column: Flag Result Banner (Upper) + PoC Walkthrough (Lower)
      Column(
        modifier = Modifier
          .weight(1.1f)
          .fillMaxHeight(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Flag result card
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = CyberRedDark.copy(alpha = 0.3f)),
          border = androidx.compose.foundation.BorderStroke(2.dp, CyberRed),
          shape = RoundedCornerShape(6.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = "FLAG RECOVERED BY AI ENGINE:",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberRedLight
              )
              Text(
                text = report.flagFound ?: "No flag identified yet",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.ExtraBold,
                  fontFamily = FontFamily.Monospace
                ),
                color = CyberGreenBright
              )
            }

            Button(
              onClick = {
                report.flagFound?.let {
                  clipboard.setText(AnnotatedString(it))
                  copied = true
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
              shape = RoundedCornerShape(4.dp),
              modifier = Modifier.testTag("ai_copy_flag_button")
            ) {
              Icon(
                imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                contentDescription = null,
                tint = CyberBlack,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(if (copied) "COPIED" else "COPY FLAG", color = CyberBlack, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
            }
          }
        }

        // PoC Walkthrough card
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
          colors = CardDefaults.cardColors(containerColor = CyberBlack),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(modifier = Modifier.fillMaxSize()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .background(CyberSurfaceVariant)
                .padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(Icons.Default.Description, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "AUTOMATED PROOF OF CONCEPT (PoC) & REMEDIATION",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
              )
            }

            Divider(color = CyberBorder, thickness = 1.dp)

            Column(
              modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
                .verticalScroll(rememberScrollState())
            ) {
              Text(
                text = report.pocWalkthrough,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = FontFamily.Monospace,
                  fontSize = 11.sp,
                  lineHeight = 16.sp
                ),
                color = CyberTextPrimary
              )
            }
          }
        }
      }
    }
  }
}
