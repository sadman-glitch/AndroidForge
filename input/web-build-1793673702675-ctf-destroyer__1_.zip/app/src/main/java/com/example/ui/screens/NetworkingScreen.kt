package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.CtfRepository
import com.example.model.Packet
import com.example.model.PacketTreeLayer
import com.example.ui.components.CyberHeader
import com.example.ui.components.HexDumpViewer
import com.example.ui.theme.*

@Composable
fun NetworkingScreen(
  onNavigateBack: () -> Unit
) {
  var filterText by remember { mutableStateOf("") }
  var appliedFilter by remember { mutableStateOf("") }
  var selectedPacket by remember { mutableStateOf<Packet?>(CtfRepository.samplePackets.getOrNull(9) ?: CtfRepository.samplePackets.first()) }
  var showFollowStreamDialog by remember { mutableStateOf(false) }
  var flagFoundBanner by remember { mutableStateOf<String?>("flag{p4ck3t_sn1ff3r_m4st3r_99}") }

  val packets = remember(appliedFilter) {
    if (appliedFilter.isBlank()) {
      CtfRepository.samplePackets
    } else {
      val lower = appliedFilter.lowercase()
      CtfRepository.samplePackets.filter { p ->
        when {
          lower == "http" -> p.protocol.equals("http", ignoreCase = true)
          lower == "tcp" -> p.protocol.equals("tcp", ignoreCase = true) || p.protocol.equals("http", ignoreCase = true)
          lower == "dns" -> p.protocol.equals("dns", ignoreCase = true)
          lower == "icmp" -> p.protocol.equals("icmp", ignoreCase = true)
          lower == "flags" || lower.contains("flag") -> p.asciiPayload.contains("flag", ignoreCase = true) || p.info.contains("flag", ignoreCase = true)
          lower.startsWith("ip.addr") -> p.source.contains(lower.substringAfter("==").trim()) || p.destination.contains(lower.substringAfter("==").trim())
          else -> p.info.contains(lower, ignoreCase = true) || p.protocol.contains(lower, ignoreCase = true) || p.asciiPayload.contains(lower, ignoreCase = true)
        }
      }
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(CyberBlack)
      .testTag("networking_screen")
  ) {
    // Header
    CyberHeader(
      title = "WIRESHARK PACKET DISSECTOR // CAPTURE_01.PCAP",
      categoryBadge = "NETWORKING",
      onBackClick = onNavigateBack,
      actions = {
        Button(
          onClick = { showFollowStreamDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
          modifier = Modifier.height(32.dp).testTag("follow_stream_button")
        ) {
          Icon(Icons.Default.SyncAlt, contentDescription = null, tint = CyberBlack, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("FOLLOW TCP STREAM", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }
      }
    )

    // Filter Bar & Controls
    Surface(
      modifier = Modifier.fillMaxWidth(),
      color = CyberSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Filter input
        Row(
          modifier = Modifier
            .weight(1f)
            .height(36.dp)
            .background(Color(0xFF0D1E16), RoundedCornerShape(4.dp))
            .border(1.dp, CyberGreen, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.FilterAlt, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Apply display filter: ",
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = CyberTextSecondary
          )
          OutlinedTextField(
            value = filterText,
            onValueChange = { filterText = it },
            modifier = Modifier.weight(1f).testTag("wireshark_filter_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = Color.Transparent,
              unfocusedBorderColor = Color.Transparent,
              focusedContainerColor = Color.Transparent,
              unfocusedContainerColor = Color.Transparent
            ),
            singleLine = true,
            placeholder = { Text("e.g. http, tcp.port == 80, ip.addr == 10.0.0.88, flag", style = MaterialTheme.typography.bodySmall, color = CyberTextMuted) },
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, color = CyberGreenBright)
          )
          if (filterText.isNotBlank()) {
            IconButton(
              onClick = {
                filterText = ""
                appliedFilter = ""
              },
              modifier = Modifier.size(20.dp)
            ) {
              Icon(Icons.Default.Close, contentDescription = "Clear", tint = CyberTextMuted, modifier = Modifier.size(14.dp))
            }
          }
        }

        Button(
          onClick = { appliedFilter = filterText },
          modifier = Modifier.height(36.dp).testTag("apply_filter_button"),
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(4.dp),
          contentPadding = PaddingValues(horizontal = 12.dp)
        ) {
          Text("APPLY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = CyberBlack)
        }

        // Quick filter chips
        FilterChipMini(label = "ALL", active = appliedFilter.isEmpty()) {
          filterText = ""
          appliedFilter = ""
        }
        FilterChipMini(label = "HTTP", active = appliedFilter == "http") {
          filterText = "http"
          appliedFilter = "http"
        }
        FilterChipMini(label = "DNS", active = appliedFilter == "dns") {
          filterText = "dns"
          appliedFilter = "dns"
        }
        FilterChipMini(label = "FLAGS ONLY", active = appliedFilter == "flags", isFlag = true) {
          filterText = "flags"
          appliedFilter = "flags"
        }
      }
    }

    // Flag banner if packet has flag
    if (selectedPacket?.asciiPayload?.contains("flag{") == true || selectedPacket?.info?.contains("flag{") == true) {
      Surface(
        modifier = Modifier.fillMaxWidth().testTag("packet_flag_alert"),
        color = CyberRedDark.copy(alpha = 0.4f),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Flag, contentDescription = null, tint = CyberRedLight, modifier = Modifier.size(16.dp))
            Text(
              text = "CTF FLAG DETECTED IN PACKET #${selectedPacket?.number}: flag{p4ck3t_sn1ff3r_m4st3r_99}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberRedLight
            )
          }
          Text(
            text = "HTTP POST EXFILTRATION // STREAM #1",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
            color = CyberGreen
          )
        }
      }
    }

    // Main 3-Pane Landscape Layout
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 10.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      // Upper Pane: Packet Table (50% height)
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        colors = CardDefaults.cardColors(containerColor = CyberBlack),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(4.dp)
      ) {
        Column(modifier = Modifier.fillMaxSize()) {
          // Table Header
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .background(CyberSurfaceVariant)
              .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("No.", modifier = Modifier.width(36.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Time", modifier = Modifier.width(64.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Source", modifier = Modifier.width(96.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Destination", modifier = Modifier.width(96.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Protocol", modifier = Modifier.width(60.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Length", modifier = Modifier.width(48.dp), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
            Text("Info", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, color = CyberTextPrimary)
          }

          Divider(color = CyberBorder, thickness = 1.dp)

          // Table Rows
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(1.dp)
          ) {
            items(packets) { packet ->
              val isSelected = selectedPacket?.number == packet.number
              val rowBg = when {
                isSelected -> CyberRedDim
                packet.asciiPayload.contains("flag{") -> Color(0xFF33161C)
                packet.protocol == "HTTP" -> PcapHttpGreen
                packet.protocol == "DNS" -> PcapDnsBlue
                packet.protocol == "ICMP" -> PcapIcmpPurple
                packet.protocol == "ARP" -> PcapArpYellow
                else -> PcapTcpGrey
              }

              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(rowBg)
                  .border(if (isSelected) 1.dp else 0.dp, if (isSelected) CyberRed else Color.Transparent)
                  .clickable { selectedPacket = packet }
                  .padding(horizontal = 6.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${packet.number}",
                  modifier = Modifier.width(36.dp),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = if (isSelected) CyberRedLight else CyberTextPrimary
                )
                Text(
                  text = packet.time,
                  modifier = Modifier.width(64.dp),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = CyberTextSecondary
                )
                Text(
                  text = packet.source,
                  modifier = Modifier.width(96.dp),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = CyberTextPrimary,
                  maxLines = 1
                )
                Text(
                  text = packet.destination,
                  modifier = Modifier.width(96.dp),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = CyberTextPrimary,
                  maxLines = 1
                )
                Text(
                  text = packet.protocol,
                  modifier = Modifier.width(60.dp),
                  style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                  ),
                  color = when (packet.protocol) {
                    "HTTP" -> CyberGreenBright
                    "DNS" -> CyberCyan
                    "ICMP" -> CyberYellow
                    else -> CyberTextPrimary
                  }
                )
                Text(
                  text = "${packet.length}",
                  modifier = Modifier.width(48.dp),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = CyberTextSecondary
                )
                Text(
                  text = packet.info,
                  modifier = Modifier.weight(1f),
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                  color = if (packet.asciiPayload.contains("flag{")) CyberRedLight else CyberTextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
            }
          }
        }
      }

      // Lower Pane: 2 Columns Split in Landscape (Packet Details Tree + Hex Dump)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1.1f),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Left: Packet Details Tree
        Card(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight(),
          colors = CardDefaults.cardColors(containerColor = CyberSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(4.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(8.dp)
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(Icons.Default.AccountTree, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
              Text(
                text = "PACKET DISSECTION TREE (PACKET #${selectedPacket?.number ?: 1})",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
              )
            }

            Divider(color = CyberBorder, thickness = 1.dp)

            if (selectedPacket != null) {
              selectedPacket!!.details.forEach { layer ->
                PacketLayerTreeItem(layer = layer)
              }
            }
          }
        }

        // Right: Hex Dump & ASCII Inspector
        Box(
          modifier = Modifier
            .weight(1.1f)
            .fillMaxHeight()
        ) {
          HexDumpViewer(
            hexData = selectedPacket?.hexBytes ?: "00 00",
            modifier = Modifier.fillMaxSize(),
            title = "PACKET #${selectedPacket?.number ?: 1} HEX DUMP"
          )
        }
      }
    }
  }

  // Follow TCP Stream Dialog
  if (showFollowStreamDialog) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    AlertDialog(
      onDismissRequest = { showFollowStreamDialog = false },
      title = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.SyncAlt, contentDescription = null, tint = CyberRed)
            Text(
              "FOLLOW TCP STREAM #1 (192.168.1.45:49822 <-> 10.0.0.88:80)",
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberTextPrimary
            )
          }
        }
      },
      text = {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp)
            .verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          // Banner
          Surface(
            color = CyberGreenDim,
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderGreen),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "FLAG CAPTURED: flag{p4ck3t_sn1ff3r_m4st3r_99}",
              modifier = Modifier.padding(8.dp),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = CyberGreenBright
            )
          }

          // Conversation Stream
          Surface(
            color = CyberBlack,
            shape = RoundedCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
          ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              // Client request in red
              Text(
                text = "GET /login.php HTTP/1.1\r\nHost: internal-target.ctf.lan\r\nUser-Agent: CTF-Destroyer-Agent/1.0\r\n\r\n",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = CyberRedLight
              )
              // Server response in blue/cyan
              Text(
                text = "HTTP/1.1 200 OK\r\nServer: Nginx-CTF\r\nContent-Type: text/html\r\n\r\n<html><body><form action=\"/api/submit_flag\" method=\"POST\"></form></body></html>",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = CyberCyan
              )
              // Client exfiltration payload in bold red
              Text(
                text = "POST /api/submit_flag HTTP/1.1\r\nHost: internal-target.ctf.lan\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\nusername=root&key=flag{p4ck3t_sn1ff3r_m4st3r_99}",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                color = CyberRedLight
              )
              // Server redirect in blue
              Text(
                text = "HTTP/1.1 302 Found\r\nLocation: /dashboard?auth=ok\r\n\r\n",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = CyberCyan
              )
            }
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            clipboard.setText(AnnotatedString("flag{p4ck3t_sn1ff3r_m4st3r_99}"))
            copied = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = CyberGreen),
          shape = RoundedCornerShape(4.dp)
        ) {
          Text(if (copied) "FLAG COPIED!" else "COPY FLAG", color = CyberBlack)
        }
      },
      dismissButton = {
        TextButton(onClick = { showFollowStreamDialog = false }) {
          Text("CLOSE", color = CyberTextSecondary)
        }
      },
      containerColor = CyberSurface,
      shape = RoundedCornerShape(8.dp)
    )
  }
}

@Composable
private fun PacketLayerTreeItem(layer: PacketTreeLayer) {
  var isExpanded by remember { mutableStateOf(true) }

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable { isExpanded = !isExpanded }
        .padding(vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
        contentDescription = null,
        tint = CyberTextSecondary,
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = layer.title,
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color = CyberTextPrimary
      )
    }

    if (isExpanded) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(start = 20.dp, top = 2.dp, bottom = 4.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
      ) {
        layer.items.forEach { (key, value) ->
          val isFlag = value.contains("flag{")
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "$key: ",
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
              color = CyberTextMuted
            )
            Text(
              text = value,
              style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isFlag) FontWeight.Bold else FontWeight.Normal
              ),
              color = if (isFlag) CyberRedLight else CyberTextPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FilterChipMini(
  label: String,
  active: Boolean,
  isFlag: Boolean = false,
  onClick: () -> Unit
) {
  Surface(
    modifier = Modifier.clickable(onClick = onClick),
    shape = RoundedCornerShape(4.dp),
    color = when {
      active && isFlag -> CyberRedDark
      active -> CyberGreenDark
      else -> CyberSurfaceVariant
    },
    border = androidx.compose.foundation.BorderStroke(
      1.dp,
      when {
        active && isFlag -> CyberRed
        active -> CyberGreen
        else -> CyberBorder
      }
    )
  ) {
    Text(
      text = label,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      style = MaterialTheme.typography.labelSmall.copy(
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold
      ),
      color = when {
        active -> CyberTextPrimary
        isFlag -> CyberRedLight
        else -> CyberTextSecondary
      }
    )
  }
}
