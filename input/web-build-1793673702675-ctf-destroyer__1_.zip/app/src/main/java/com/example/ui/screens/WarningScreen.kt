package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun WarningScreen(
  onAcceptAndProceed: () -> Unit
) {
  var rulesAccepted by remember { mutableStateOf(false) }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(CyberRedDark.copy(alpha = 0.5f), CyberBlack, Color(0xFF040608)),
          radius = 1200f
        )
      )
      .testTag("warning_screen")
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 24.dp, vertical = 14.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Header Banner
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = CyberRed.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(2.dp, CyberRed),
        shape = RoundedCornerShape(8.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = "Warning",
            tint = CyberRedLight,
            modifier = Modifier.size(30.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "AUTHORIZED EDUCATIONAL & DEFENSIVE RESEARCH ONLY",
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
              ),
              color = CyberRedLight
            )
            Text(
              text = "SECURITY CLEARANCE: ETHICAL HACKING & CTF RULES OF ENGAGEMENT",
              style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.5.sp),
              color = CyberTextSecondary
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Icon(
            imageVector = Icons.Default.GppMaybe,
            contentDescription = "Security Alert",
            tint = CyberRedLight,
            modifier = Modifier.size(30.dp)
          )
        }
      }

      // Main Content Box (Two Columns in Landscape)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        // Left Column: Legal notice & RoE breakdown
        Card(
          modifier = Modifier
            .weight(1.2f)
            .fillMaxHeight(),
          colors = CardDefaults.cardColors(containerColor = CyberSurface.copy(alpha = 0.9f)),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed),
          shape = RoundedCornerShape(8.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(14.dp)
              .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = CyberRed,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = "RULES OF ENGAGEMENT (RoE) MANDATE",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary
              )
            }

            Divider(color = CyberBorder, thickness = 1.dp)

            RoEItem(
              number = "01",
              title = "Authorized Testing Only",
              description = "All network analysis, memory forensics, exploit payloads, and reverse engineering tools in CTF DESTROYER must only be directed against challenges, CTF competitions, or systems where you possess explicit written authorization."
            )

            RoEItem(
              number = "02",
              title = "Statutory Compliance",
              description = "Unauthorized access, probing, data exfiltration, or denial of service is illegal under 18 U.S.C. § 1030 (Computer Fraud and Abuse Act) and international cyber laws."
            )

            RoEItem(
              number = "03",
              title = "Responsible Disclosure & White Hat Oath",
              description = "Any vulnerabilities discovered in external infrastructures during independent research must be reported responsibly through official security disclosure channels."
            )
          }
        }

        // Right Column: Acknowledgment Checkbox & Proceed Button
        Card(
          modifier = Modifier
            .weight(0.8f)
            .fillMaxHeight(),
          colors = CardDefaults.cardColors(containerColor = CyberBlack),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
          shape = RoundedCornerShape(8.dp)
        ) {
          Column(
            modifier = Modifier
              .fillMaxSize()
              .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              Surface(
                modifier = Modifier.size(54.dp),
                shape = RoundedCornerShape(27.dp),
                color = CyberRedDim,
                border = androidx.compose.foundation.BorderStroke(2.dp, CyberRed)
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = CyberRed,
                    modifier = Modifier.size(28.dp)
                  )
                }
              }

              Text(
                text = "OPERATOR ETHICAL ATTESTATION",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = CyberTextPrimary,
                textAlign = TextAlign.Center
              )

              Text(
                text = "By unlocking this terminal, you certify under penalty of law that you are utilizing these cybersecurity tools for strictly educational, defensive, and authorized CTF training.",
                style = MaterialTheme.typography.bodySmall,
                color = CyberTextSecondary,
                textAlign = TextAlign.Center
              )

              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(6.dp))
                  .background(CyberSurfaceVariant)
                  .border(1.dp, if (rulesAccepted) CyberBorderGreen else CyberBorder, RoundedCornerShape(6.dp))
                  .padding(8.dp)
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  Checkbox(
                    checked = rulesAccepted,
                    onCheckedChange = { rulesAccepted = it },
                    colors = CheckboxDefaults.colors(
                      checkedColor = CyberGreen,
                      uncheckedColor = CyberRedLight,
                      checkmarkColor = CyberBlack
                    ),
                    modifier = Modifier.testTag("warning_checkbox")
                  )
                  Text(
                    text = "I ACCEPT THE RULES OF ENGAGEMENT & ETHICS CODE",
                    style = MaterialTheme.typography.labelSmall.copy(
                      fontWeight = FontWeight.Bold,
                      fontSize = 11.sp
                    ),
                    color = if (rulesAccepted) CyberGreenBright else CyberTextPrimary
                  )
                }
              }
            }

            // Accept & Enter button
            Button(
              onClick = onAcceptAndProceed,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("warning_accept_button"),
              colors = ButtonDefaults.buttonColors(
                containerColor = CyberRed,
                disabledContainerColor = CyberSurfaceVariant
              ),
              enabled = rulesAccepted,
              shape = RoundedCornerShape(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.VpnKey,
                contentDescription = null,
                tint = if (rulesAccepted) CyberBlack else CyberTextMuted,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "ACKNOWLEDGE & ENTER CTF DESTROYER",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.ExtraBold,
                  letterSpacing = 0.5.sp
                ),
                color = if (rulesAccepted) CyberBlack else CyberTextMuted
              )
            }
          }
        }
      }

      // Bottom Telemetry Ticker
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(CyberBlack)
          .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "AUDIT ID: ROE-2026-ETHICS-ACKNOWLEDGED",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
          color = CyberTextMuted
        )
        Text(
          text = "STATION: SECURE_SANDBOX // LANDSCAPE OPERATIONAL MODE",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
          color = CyberGreen
        )
      }
    }
  }
}

@Composable
private fun RoEItem(number: String, title: String, description: String) {
  Row(
    horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalAlignment = Alignment.Top
  ) {
    Surface(
      color = CyberRedDark.copy(alpha = 0.3f),
      shape = RoundedCornerShape(4.dp),
      border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorderRed)
    ) {
      Text(
        text = number,
        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
        color = CyberRedLight
      )
    }

    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = title,
        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
        color = CyberTextPrimary
      )
      Text(
        text = description,
        style = MaterialTheme.typography.bodySmall,
        color = CyberTextSecondary
      )
    }
  }
}
