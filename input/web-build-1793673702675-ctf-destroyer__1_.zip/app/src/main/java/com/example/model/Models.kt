package com.example.model

enum class Screen(val title: String, val categoryTag: String) {
  WARNING("Ethics & RoE", "ROE"),
  LOGIN("Operator Login", "AUTH"),
  DASHBOARD("CTF Command Center", "HQ"),
  FORENSICS("Digital Forensics", "FORENSICS"),
  NETWORKING("Packet Analyzer", "NETWORKING"),
  CRYPTOGRAPHY("Cryptographic Lab", "CRYPTO"),
  REVERSE_ENGINEERING("Binary Reversing", "REV"),
  WEB_SECURITY("Web Application Security", "WEB"),
  STEGANOGRAPHY("Steganography Lab", "STEGO"),
  OSINT("Cyber Reconnaissance", "OSINT"),
  AI_SOLVER("AI Auto Solver", "AI")
}

data class CtfChallenge(
  val title: String,
  val category: String,
  val difficulty: String,
  val description: String,
  val hints: List<String>,
  val sampleFileName: String,
  val flagPattern: String
)

data class AttachedFile(
  val name: String,
  val sizeBytes: Long,
  val mimeType: String,
  val md5: String,
  val sha256: String,
  val previewText: String = "",
  val isCustomUploaded: Boolean = false
)

data class Packet(
  val number: Int,
  val time: String,
  val source: String,
  val destination: String,
  val protocol: String,
  val length: Int,
  val info: String,
  val hexBytes: String,
  val asciiPayload: String,
  val streamId: Int,
  val details: List<PacketTreeLayer>
)

data class PacketTreeLayer(
  val title: String,
  val items: List<Pair<String, String>>
)

enum class ForensicType {
  DATA_SOURCE,
  DELETED_FILE,
  WEB_HISTORY,
  SYSTEM_REGISTRY,
  EXECUTABLE_BINARY,
  EXIF_METADATA,
  FLAG_CANDIDATE
}

data class ForensicItem(
  val id: String,
  val name: String,
  val type: ForensicType,
  val path: String,
  val size: String,
  val created: String,
  val modified: String,
  val md5: String,
  val sha256: String,
  val status: String,
  val hexSnippet: String,
  val stringsContent: String,
  val metadataAttributes: Map<String, String>,
  val extractedFlag: String? = null
)

data class DisassemblyInstruction(
  val address: String,
  val opcode: String,
  val instruction: String,
  val comment: String = ""
)

data class WebExploitPayload(
  val name: String,
  val category: String,
  val payload: String,
  val description: String,
  val expectedBypass: String
)

data class AiSolveReport(
  val flagFound: String?,
  val confidenceScore: Int,
  val executionTimeMs: Long,
  val detectedFormat: String,
  val stages: List<AiSolveStage>,
  val pocWalkthrough: String
)

data class AiSolveStage(
  val name: String,
  val status: String, // SUCCESS, SKIPPED, ANALYZED
  val finding: String
)
