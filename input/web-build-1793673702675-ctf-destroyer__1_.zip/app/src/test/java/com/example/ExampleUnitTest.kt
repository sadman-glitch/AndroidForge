package com.example

import com.example.data.CtfRepository
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testRot13Cipher() {
    val input = "flag{test}"
    val encrypted = CtfRepository.rot13(input, 13)
    val decrypted = CtfRepository.rot13(encrypted, 13)
    assertEquals(input, decrypted)
  }

  @Test
  fun testMd5AndSha256() {
    val input = "root"
    val md5 = CtfRepository.calculateMd5(input)
    val sha256 = CtfRepository.calculateSha256(input)
    assertEquals("63a9f0ea7bb98050796b649e85481845", md5)
    assertTrue(sha256.isNotEmpty())
    assertEquals(64, sha256.length)
  }

  @Test
  fun testAiSolvePipelineExtractsFlag() {
    val report = CtfRepository.runAiSolvePipeline(
      challengeDesc = "Find the exfiltrated flag in the network stream",
      attachedFile = CtfRepository.sampleFiles.first()
    )
    assertNotNull(report.flagFound)
    assertTrue(report.flagFound!!.contains("flag{"))
    assertEquals(4, report.stages.size)
  }

  @Test
  fun testForensicAndPacketDataIntegrity() {
    assertTrue(CtfRepository.samplePackets.isNotEmpty())
    assertTrue(CtfRepository.sampleForensicItems.isNotEmpty())
    assertTrue(CtfRepository.sampleChallenges.isNotEmpty())
  }
}
