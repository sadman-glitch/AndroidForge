package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {

  @Test
  fun `verify app identity and naming`() {
    assertEquals("CTF DESTROYER", "CTF DESTROYER")
  }
}
